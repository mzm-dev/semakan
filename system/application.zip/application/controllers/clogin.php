<?php

class Clogin extends Controller {
    function Clogin() {
        parent::Controller();
        session_start();
        
    }

    function index(){
       if($this->my_ses->logged_in){
            //User is logged in
                    $data['title'] = 'Sistem Helpdesk Generik';
                    $data['main'] = 'utama';
                    $data['tahap'] = $this->session->userdata('tahap');
                    $data['id'] = $this->session->userdata('id');
					if($data['tahap'] == 'klien'){
						$data['page'] = 'home_user';	
					}elseif($data['tahap'] == 'admin'){
						$data['page'] = 'home_admin';	
					}elseif($data['tahap'] == 'petugas'){
						$data['page'] = 'home_petugas';	
					}
					$this->load->model('MPengumuman');
         	 		 $data['pengumuman'] = $this->MPengumuman->senaraiPengumuman('1');
					//$data['menu'] = 'index';
                    $this->load->vars($data);
                    $this->load->view('template');
        } else {
                //User is not logged in           
                 $this->load->view('vlogin');
                    } 
    }

    function login() {
        $this->load->model('MPersonal');
        $this->load->model('MKategori');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('no_kp', 'No KP', 'required');
		$this->form_validation->set_rules('katalaluan', 'Katalaluan', 'required');
		
         $data['kat'] = $this->MKategori->getKategori();
         //$data['subkat'] = $this->MKategori->getSubKategori();
         if ($this->form_validation->run() == FALSE)
		{		
				 $data['login_failed'] = "Kombinasi nama dan kata laluan tidak tepat";
             $this->load->vars($data);
             //redirect('clogin/','refresh');
             $this->load->view('vlogin',$data);
		}else{
        if($this->MPersonal->login($_POST['no_kp'], $_POST['katalaluan'])) {
              $data['logmasuk'] = $this->MPersonal->getPersonal($_POST['no_kp']);
              // $_SESSION['logged_in'] = 1;
              // $_SESSION['tahap'] = $data['logmasuk']['tahap'];
               $data = array(
                    'id' => $data['logmasuk']['no_kp'],
                   'tahap' => $data['logmasuk']['tahap'],
				'logged_in' => true
			);
             		$this->session->set_userdata($data);
                   $data['title'] = 'Sistem Helpdesk Generik';
                    $data['main'] = 'utama';
					
                    if($data['tahap'] ==  'admin'){
                         redirect('pentadbir/cadmin');
                    }elseif($data['tahap'] ==  'petugas'){
                         redirect('petugas/cpetugas');
                    }else{
                    	redirect('clogin/','refresh');
                    }
                   
               
           }else{
        
             $data['login_failed'] = "Kombinasi nama dan kata laluan tidak tepat";
             $this->load->vars($data);
             //redirect('clogin/','refresh');
             $this->load->view('vlogin',$data);
        }
    }
    }

    
   function logout()
  {
      $this->session->sess_destroy();     
      redirect('clogin/','refresh');
       }

    function pendaftaran(){
      
                    $data['title'] = 'Sistem Helpdesk Generik';
                    $data['title'] = 'pendaftaran';
                    $this->load->vars($data);
                    $this->load->view('pendaftaran');
       
    }
	
	function prosesdaftar(){
		$this->load->model('MPersonal');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('nama', 'Username', 'required');
		$this->form_validation->set_rules('no_kp', 'kp', 'required');
		$this->form_validation->set_rules('katalaluan1', 'Password', 'required');
		//$this->form_validation->set_message('required', 'Your custom message here');
		if ($this->form_validation->run() == FALSE)
		{		
				$this->load->view('pendaftaran');
		}else{
		$data['personal'] = $this->MPersonal->getPersonal($_POST['no_kp']);
		if(isset($data['personal']['no_kp'])){
			$data['telah_wujud'] = 'Nama dan No KP tersebut telah wujud.';
			$this->load->vars($data);
                    $this->load->view('pendaftaran');
		}else{
			if($_POST['katalaluan1'] == $_POST['katalaluan2']){
				$postdata = array(
	            'nama'=>$_POST['nama'],
	            'no_kp'=>$_POST['no_kp'],
	            'emel'=>$_POST['emel'],
	            'katalaluan'=>$_POST['katalaluan1'],
	            'tahap'=>'klien'
	             );
	            $this->MPersonal->insertPerson($postdata);	
				$data['success'] = 'Pendaftaran berjaya. Sila log masuk dengan No KP dan Katalaluan anda.';
				 $this->load->vars($data);             
	             $this->load->view('vlogin',$data);
			}else{
				$data['telah_wujud'] = 'Kombinasi kata laluan tidak sama';
				$this->load->vars($data);
				$this->load->view('pendaftaran');
			}
		}
		}
		
		
	}

}
?>

<?php
class CFaq extends Controller{

	var $fixvar;
	
    function CFaq(){
        parent::Controller();
        session_start();
		$this->fixvar['page']= 'kb';	
		$this->load->vars($this->fixvar);
    }

	function nilaiFaq(){
		if($this->input->post('Ya') == 'Ya'){
			echo 'Terima kasih';
		}else if($this->input->post('Tidak') == 'Tidak'){
			echo 'Sudahkan anda mencuba penyelesaian berikut:-';
		}
		
	}
	
    function carianFaq()
        {
        if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
         $this->load->model('MKategori');
         $this->load->model('MFaq');
        $data['query'] = $this->MFaq->cariFaq();
		$data['kat'] = $this->MKategori->getKategori();
        $data['title'] = 'Hasil Carian';
        $data['main'] = 'main_faq';
        $this->load->view('template', $data);
         }
        }
     
     function carianFaqMain()
        {
        if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
         $this->load->model('MKategori');
         $this->load->model('MFaq');
        $data['query'] = $this->MFaq->cariFaq();
        $data['kat'] = $this->MKategori->getKategori();
		$data['match'] = $this->input->post('perkara');
		$this->session->set_flashdata('katakunci',$data['match']);
		
        $data['title'] ='Knowledge Base';
            $data['main'] ='indexKB';
             $this->load->vars($data);
        $this->load->view('template', $data);
         }
        }
    
    
    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
           $data['id'] = $this->session->userdata('id');
             $this->load->model('MKategori');
             $data['kat'] = $this->MKategori->getKategori();
             $data['title'] ='Knowledge Base';
            $data['main'] ='indexKB';
             $this->load->vars($data);
          $this->load->view('template');
        }
    }    

	function ajx_getList($katakunci){
		$katakunci = str_replace('_', ' ', $katakunci);
		$this->session->set_flashdata('katakunci',$katakunci);
		 $this->load->model('MFaq');
		  $this->load->model('MKategori');
        $query = $this->MFaq->cariRelatedFaq($katakunci);
		$str = 'Mungkin anda boleh mencuba salah satu dari penyelesaian berikut.';
		$str .= '<ul>';
		foreach($query as $item){
			$str .= '<li><a href='.base_url().'index.php/cfaq/detailfaq/'.$item['id'].'>'.$item['soalan'].'</li></a>';
        }
        
       $str .= '</ul>';
        echo $str;
		
		
	}
	
	function ajx_terimaKasih(){
		echo '<strong>Terima Kasih Atas MaklumBalas Anda</strong>';
	}
    
    function senaraikb($kategori){
         if($this->my_ses->logged_in){
                $data['tahap'] = $this->session->userdata('tahap');
                $data['id'] = $this->session->userdata('id');
             $this->load->model('MKategori');
             $this->load->model('MFaq');
             $namakat = $this->MKategori->getNamaKategori($kategori);
             $data['senarai'] = $this->MFaq->getSenaraiKB($kategori);
             $data['title'] ='Knowledge Base | Kategori '.$namakat;
            $data['main'] ='senaraiKB';
             $this->load->vars($data);
          $this->load->view('template');
        }
    }    
    
    
    function detailFaq($id_faq){
    	if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $data['katakunci'] = $this->session->flashdata('katakunci'); 
			 $this->session->set_flashdata('katakunci',$data['katakunci']);
         $this->load->model('MKategori');
		  $this->load->model('MFaq');
         $data['kat'] = $this->MKategori->getKategori();
		 $data['faq'] = $this->MFaq->detailFaq($id_faq);
		 
            $data['title'] =$data['faq']['soalan'];
            $data['main'] ='detail_faq';
             $this->load->vars($data);
          $this->load->view('template');
        }
		
    }
	
	 function insert(){
        $data = array(
            'soalan'=>$_POST['soalan'],
            'jawapan'=>$_POST['jawapan'],
            'kategori'=>$_POST['kategori'],
            'sub_kategori'=>$_POST['sub_kategori'],
             'papar'=>$_POST['papar'],
			 'tarikh'=>date( 'Y-m-d H:i:s')
          );
        $this->load->model('MFaq');
        $this->MFaq->insertFaq($data);
         redirect(base_url().'index.php/pentadbir/cfaqadmin/','refresh');

    }
	
	function updaterating(){
		//simpan rate dan bilangan pengundi
		//tambah rate dan bilangan pengundi sebelum ni
		//jumlah rate = purata rate X bilangan pengundi sebelum ni
		//jumlah rate + rate baru/(bilangan pengundi sebelum ni + 1)
		print_r($_POST['star1']);
		$data = array(
            'soalan'=>$_POST['soalan'],
            'jawapan'=>$_POST['jawapan'],            
            );
		 $this->load->model('MFaq');
		  $this->MFaq->updaterating($data);
		 
	}

    function ajx_subkat($kod_kat){
       // echo $kod_kat;exit;
        $this->load->model('MKategori');
        $subkat = $this->MKategori->getSubKategori($kod_kat);
        $str ="<label for=Sub Kategori>Sub Kategori</label>";
        $str .= "<select name=sub_kategori id=sub_kategori>";
        $str .="<option>---Sila Pilih---</option>";
        foreach($subkat as $row){
            $str.="<option value=".$row['id'].">".$row['nama_subkategori']."</option>";
        }
        $str.="</select>";
        echo $str;
    }

     

}

<?php
class CAduan extends Controller{
    	
	function CAduan(){
        parent::Controller();
        session_start();
		$this->load->library('usertracking');
        $this->usertracking->track_this();
    }

    function insert(){
        if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
      
        /* Create the config for upload library */
	      //$config['upload_path'] = '/var/www/help_desk/uploads/'; /* NB! create this dir! */
             $config['upload_path'] = 'C:\xampp\htdocs\help_desk\uploads'; /* NB! create this dir! */
             
              $config['allowed_types'] = 'gif|jpg|png|bmp|jpeg|pdf';
	      $config['max_size']  = '0';
	      $config['max_width']  = '0';
	      $config['max_height']  = '0';
	      /* Load the upload library */
	      $this->load->library('upload', $config);
	
      if(!empty($_FILES['lampiran1']['name'])){       
        /* Handle the file upload */
        $upload = $this->upload->do_upload('lampiran1');
        /* File failed to upload - continue 
        if($upload === FALSE) continue;*/
        /* Get the data about the file */
        $faildata = $this->upload->data();
        $lampiran1 = $faildata['file_name'];
        
      }else{
      	$lampiran1 ="";
      }
       if(!empty($_FILES['lampiran2']['name'])){
        /* Handle the file upload */
        $upload = $this->upload->do_upload('lampiran2');
        /* File failed to upload - continue 
        if($upload === FALSE) continue;*/
        /* Get the data about the file */
        $faildata = $this->upload->data();
        $lampiran2 = $faildata['file_name'];
      }else{
      	$lampiran2="";
      }

      /******************* Insert Into DB*****************************************/

        $postdata = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'emel'=>$_POST['emel'],
            'kategori'=>$_POST['kategori'],
            'sub_kategori'=>$_POST['sub_kategori'],
            'keutamaan'=>$_POST['keutamaan'],
            'perkara'=>$_POST['perkara'],
            'keterangan'=>$_POST['keterangan'],
             'tarikh_aduan'=>date( 'Y-m-d H:i:s'),
            'status'=>'Baru',
            'lampiran1'=>$lampiran1,
             'lampiran2'=>$lampiran2
          );


            $this->load->model('MAduan');
            $this->MAduan->insert($postdata);
            $this->load->model('MKategori');
			 $this->load->model('MPersonal');
         	 $data['personal'] = $this->MPersonal->getPersonal($data['id']);
            $data['id_aduan'] = $this->MAduan->aduanTerakhir();
            $data['kat'] = $this->MKategori->getKategori();
            $data['title'] ='Hantar Aduan';
            $data['main'] ='add_aduan';

            $kandungan  = $_POST['nama'].",

            Aduan tuan/puan telah diterima. No. Aduan: ".$data['id_aduan']." telah diwujudkan.
            Tindakan susulan akan diambil ke atas aduan ini.

            Sila log masuk melalui http://localhost/help_desk/index.php/caduan/semakaduan untuk menyemak status aduan anda.

            Sekian, TerimaKasih.";

            $this->email->from('ardzryhafeez@yahoo.com','Sistem Help Desk');
            $this->email->to($_POST['emel']);
            $this->email->subject('test');
            $this->email->message($kandungan);
            $this->email->send();
               
            
			$data['page'] = 'aduan';
          $this->load->vars($data);
          $this->load->view('template');

          }
    }

    function butiranAduan($id_aduan){
     if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

             $this->load->model('MAduan');
             $this->load->model('MPersonal');
             $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');          
             //$data['butiran'] = $this->MAduan->semakAduan($_POST['emel'], $_POST['rujukan']);
             $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
              $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($data['butiran']['id']);
			                
             $data['main'] ='butiran_aduan';
             $data['title'] ='Butiran Aduan';
			 $data['page'] ='status_aduan';
             $this->load->vars($data);
             $this->load->view('template');
             }
    }

    function suggestions()
	    {

	    $this->load->model('MFaq');
	    $term = $this->input->post('term',TRUE);

	    if (strlen($term) < 2) break;

	    $rows = $this->MFaq->autoCompleteFaq();

	    $keywords = array();
         

	    foreach ($rows as $row)
	    	 //array_push($keywords,array($row->id.":".$row->soalan));        
	    	 array_push($keywords,$row->id.":".$row->soalan);
                echo json_encode($keywords);
			
	    }
		
	function json_zip(){
        $this->load->model('MFaq');           
        
        $locations = $this->MFaq->autoJson();
        
        if(count($locations) > 0){
                        
            foreach($locations as $location){
               
			   $data['message'][] = array(
            									'label' => $location->soalan ,
           										 'value' => $location->id
      									  );
            }
            
          
        }
        echo json_encode($data);       
     }
	
    
    function statusAduan()
        {
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
             $this->load->model('MAduan');
             $data['senarai'] = $this->MAduan->senaraiAduanPengadu($data['id']);
				 $data['title'] = 'Semak Status Aduan';
				 $data['main'] = 'indexSA';
				 $data['page'] ='status_aduan';
				 $this->load->view('template', $data);
            }else{
                 redirect('clogin/','refresh');
            }
        }
        
    function cariAduan()
        {
         if($this->my_ses->logged_in){
            $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
             $id_aduan = $this->input->post('id_aduan');

             $this->load->model('MAduan'); 
             $this->load->model('MPersonal');
             $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');         
             $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
             $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($data['butiran']['id']);
			                
             $data['main'] ='butiran_aduan';
             $data['title'] ='Butiran Aduan';
			 $data['page'] ='status_aduan';
             $this->load->vars($data);
             $this->load->view('template');
			 
            }else{
                 redirect('clogin/','refresh');
            }
        }


    function index(){
       if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
                    $data['id'] = $this->session->userdata('id');
             $this->load->model('MKategori');
			 $this->load->model('MPersonal');
         	 $data['kat'] = $this->MKategori->getKategori();
			 $data['personal'] = $this->MPersonal->getPersonal($data['id']);
            $data['title'] ='Hantar Aduan';
            $data['main'] ='add_aduan';
			$data['page'] ='aduan';
             $this->load->vars($data);
            $this->load->view('template');
        }else{
               redirect('clogin/','refresh');
        }

    }

    function maklumbalasAduan($id_aduan){
		 if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
		$this->load->model('MAduan');
        $this->load->model('MPersonal');
		 $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');      
		
		if(isset($_POST['status'])){
			$this->MAduan->updateStatusAduan($id_aduan);
		}
		
		$lampiran_mklm_bls = "";
		
		 $postdata = array(
				'id_aduan' => $id_aduan,
                                'no_kp'=>$data['id'],
                                'kandungan' => $_POST['kandungan_mklmbls'],
                                'tarikh_mklm_bls' => date( 'Y-m-d H:i:s'),
                                'lampiran' => $lampiran_mklm_bls
                     );	
                 $this->MAduan->insertMklmBlsAduan($postdata);
                  $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
                  $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($id_aduan);
                 
		  $data['main'] ='butiran_aduan';
             $data['title'] ='Butiran Aduan';
			 $data['page'] ='status_aduan';
             $this->load->vars($data);
             $this->load->view('template');
		 }
    }

    function reg_form(){
        $this->load->model('MJabatan');
        $data['jab'] = $this->MJabatan->getJabatan();
        $this->load->vars($data);
        $this->load->view('staf/vstaff_reg');
    }

    function ajx_subkat($kod_kat,$kod_sub = ''){
       // echo $kod_kat;exit;
        $this->load->model('MKategori');		
        $subkat = $this->MKategori->getSubKategori($kod_kat);
        $str  = "<label  class='form-label fl-space2'>Sub Kategori:</label>";
        $str .= "<select name=sub_kategori id=sub_kategori>";
        $str .="<option>---Sila Pilih---</option>";
		foreach($subkat as $row){
			if(($kod_sub!='') && ($kod_sub == $row['id'])){ 
												                 	$selected="selected='selected'";					
												                            }else{
												                                 $selected="";	  
												                           }
            $str.="<option ".$selected."value=".$row['id'].">".$row['nama_subkategori']."</option>";
        }
        $str.="</select>";
       
        echo $str;
    }

	function padamAduan($id_aduan){
		 $this->load->model('MAduan');
		 $this->MAduan->padamAduan($id_aduan);
		 
	}	
	
	
	
}

<?php
class CInteract extends Controller{
	
	var $fixvar;
	
    function CInteract(){
        parent::Controller();
        session_start();
		$this->fixvar['page']= 'interact';	
		$this->load->vars($this->fixvar);
		 
    }
	
	function index(){
	 if($this->my_ses->logged_in){
                $data['tahap'] = $this->session->userdata('tahap');
                $data['id'] = $this->session->userdata('id');
                
                $this->load->model('MPersonal');
                //$data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');
                $data['petugas'] = $this->MPersonal->getOnlineUser();
				$data['title'] ='Interaksi dengan petugas';
				$data['main'] ='startChat';
				$this->load->vars($data);
				$this->load->view('template');
             }
	}
        
    function chat($me, $you)
    {
        if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
             $data['title'] ='Interaksi dengan petugas';
            $data['me'] = $me;
            $data['you'] = $you;          
            $data['main'] = 'chatty';
            $this->load->vars($data);
                                    $this->load->view('template');
           // $this->load->view('chatty', $data);
        }
    }
	
   
	
	
}
<?php
class CLaporan extends Controller{

    function CLaporan(){
        parent::Controller();
        session_start();
		$this->load->helper('url');
        $this->load->plugin('jpgraph');   
       
    }
	
	function index(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
         	  $data['main'] ='pentadbir/senarai_laporan';
         	 $data['title'] ='Laporan';
		     $this->load->vars($data);
             $this->load->view('template');
		}
	}
	
	function laporan_bulan(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			  $this->load->model('MKategori');
			 $data['kat'] = $this->MKategori->getKategori();
         	 $data['main'] ='pentadbir/laporan_bulan';
         	 $data['title'] ='Laporan';
		     $this->load->vars($data);
             $this->load->view('template');
		}
	}
	
	function kategori_laporan_bulan(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MAduan');
			 $data['tahun'] = $this->input->post('tahun');
			 $data['bulan'] = $this->input->post('bulan');
			 $data['main'] ='pentadbir/senarai_kategori_laporan_bulan';
         	 $data['title'] ='Laporan';
		     $this->load->vars($data);
             $this->load->view('template');
		}
	}
	
	function kat_masalah_bulan($tahun,$bulan){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MAduan');
			 $data['laporan'] = $this->MAduan->stat_kat_bulan($tahun,$bulan);
			 
			$data['main'] ='pentadbir/kat_masalah_bulan';
         	 $data['title'] ='Laporan Statistik Bulanan Mengikut Kategori';
			foreach ($data['laporan']->result() as $row)
			{
				 $ydata[] = $row->bil;	
				 		   
			}
			
			 $legend = array('Perisian','Perkakasan','Rangkaian','Password/Emel'); // this should come from the model       
			 $graph = piechart($ydata,$legend, 'Carta Pai Statistik');  // add more parameters to plugin function as required
	        	        
	        $graph_temp_directory = 'temp';  // in the webroot (add directory to .htaccess exclude)
	        $graph_file_name = 'test.png';    
	        
	        $graph_file_location = $graph_temp_directory . '/' . $graph_file_name;
	         
			@unlink($graph_file_location);
		    $graph->Stroke('./'.$graph_file_location);  // create the graph and write to file
	      
	        $data['graph'] = $graph_file_location;
			
		     $this->load->vars($data);
             $this->load->view('template');
			  
		}
		}

	function kat_status_bulan($tahun,$bulan){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MAduan');
			 $data['laporan'] = $this->MAduan->stat_status_bulan($tahun,$bulan);
			 
			$data['main'] ='pentadbir/kat_status_bulan';
         	 $data['title'] ='Laporan Statistik Bulanan Mengikut Kategori';
			foreach ($data['laporan']->result() as $row)
			{
				 $ydata[] = $row->bil;	
				 		   
			}
			
			 $legend = array('Baru','Dalam Tindakan','Diagih','Selesai'); // this should come from the model       
			 $graph = piechart($ydata,$legend, 'Carta Pai Statistik');  // add more parameters to plugin function as required
	        	        
	        $graph_temp_directory = 'temp';  // in the webroot (add directory to .htaccess exclude)
	        $graph_file_name = 'test.png';    
	        
	        $graph_file_location = $graph_temp_directory . '/' . $graph_file_name;
	         
			@unlink($graph_file_location);
		    $graph->Stroke('./'.$graph_file_location);  // create the graph and write to file
	      
	        $data['graph'] = $graph_file_location;
			
		     $this->load->vars($data);
             $this->load->view('template');
			  
		}
	}

	function kat_petugas_bulan($tahun,$bulan){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MAduan');
			 $data['laporan'] = $this->MAduan->stat_petugas_bulan($tahun,$bulan);
			 
			$data['main'] ='pentadbir/kat_petugas_bulan';
         	 $data['title'] ='Laporan Statistik Bulanan Mengikut Kategori';
			foreach ($data['laporan']->result() as $row)
			{
				 $ydata[] = $row->bil;	
				 $legend[]= $row->nama;		   
			}
			
			 //$legend = array('Baru','Dalam Tindakan','Diagih','Selesai'); // this should come from the model       
			 $graph = bargraph($ydata, $legend, 'Carta Bar Statistik');  // add more parameters to plugin function as required
	        	        
	        $graph_temp_directory = 'temp';  // in the webroot (add directory to .htaccess exclude)
	        $graph_file_name = 'test.png';    
	        
	        $graph_file_location = $graph_temp_directory . '/' . $graph_file_name;
	         
			@unlink($graph_file_location);
		    $graph->Stroke('./'.$graph_file_location);  // create the graph and write to file
	      
	        $data['graph'] = $graph_file_location;
			
		     $this->load->vars($data);
             $this->load->view('template');
			  
		}
	}


}
<?php
class CAduanAdmin extends Controller{

    function CAduanAdmin(){
        parent::Controller();
        session_start();
		$this->load->library('usertracking');
        $this->usertracking->track_this();
       
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'jab'=>$_POST['jab']
          );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);


    }

    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

              $this->load->model('MAduan');
              $data['aduanbaru'] = $this->MAduan->getAduanBaru();
             $data['main'] ='pentadbir/senarai_aduan';
             $data['title'] ='Senarai Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
    }
	
	 function senaraiAgihan(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

              $this->load->model('MAduan');
              $data['aduanbaru'] = $this->MAduan->getAduanDiagih();
             $data['main'] ='pentadbir/senarai_aduan';
             $data['title'] ='Senarai Aduan Yang Telah Diagih';
             $this->load->vars($data);
             $this->load->view('template');
         }
    }
	
	function kemaskini($id_aduan){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

              $this->load->model('MAduan');
		 $this->load->model('MPersonal');
		 $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');               
              $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
              $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($id_aduan);
	     $data['personal'] = $this->MPersonal->getPersonal($data['butiran']['pegawai_kes']);
             $data['main'] ='butiran_aduan';
             $data['title'] ='Butiran Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
			
    }
	
	function kemaskiniAgihan($id_aduan){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

              $this->load->model('MAduan');
			  $this->load->model('MPersonal');
			  
			  $this->MAduan->updateAgihan($id_aduan);
                          
             $data['main'] ='butiran_aduan';
			  $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');
			  $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
			  $data['personal'] = $this->MPersonal->getPersonal($data['butiran']['pegawai_kes']);
                           $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($data['butiran']['no_kp']);
			  
             $data['title'] ='Butiran Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
	}
	
	function padamAduan($id_aduan){
		 $this->load->model('MAduan');
		 $this->MAduan->padamAduan($id_aduan);
		 
	}
	
	function terima($id_aduan){
		 if($this->my_ses->logged_in){				
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');

              $this->load->model('MPersonal');
			  $this->load->model('MAduan');
		 		$this->MAduan->terimaAduan($id_aduan);
                          
             $data['main'] ='butiran_aduan';
			  $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');
			  $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
			  $data['personal'] = $this->MPersonal->getPersonal($data['butiran']['pegawai_kes']);
                           $data['sen_mklmbls'] = $this->MAduan->getMklmBlsAduan($data['butiran']['no_kp']);
			  
             $data['title'] ='Butiran Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
	}



}

<?php
class CAdmin extends Controller{

    function CAdmin(){
        parent::Controller();
        session_start();
       
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'jab'=>$_POST['jab']
          );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);


    }

    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MPengumuman');
         	 $data['pengumuman'] = $this->MPengumuman->senaraiPengumuman('1');
             $data['main'] ='pentadbir/utama_admin';
	         $data['title'] ='Laman Utama Pentadbir';
			 $data['menu'] = 'index';
	         $this->load->vars($data);
	        $this->load->view('template');
         }

    }




}

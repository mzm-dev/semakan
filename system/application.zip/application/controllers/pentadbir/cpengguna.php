<?php
class CPengguna extends Controller{

    function CPengguna(){
        parent::Controller();
        session_start();
       
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'jab'=>$_POST['jab']
          );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);


    }

    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');			 
             $data['main'] ='pentadbir/indexPengguna';
	         $data['title'] ='Laman Utama Pentadbir';
			 $this->load->vars($data);
	        $this->load->view('template');
         }

    }
	
	function edit_page($id_pengguna = NULL){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MPersonal');
          	 $data['main'] ='pentadbir/new_pengguna';
             $data['title'] ='Tambah Pengumuman Baru';
			 $data['pengumuman'] = $this->MPersonal->getPersonal($id_pengguna);
			 $data['action'] = 'edit';
		     $this->load->vars($data);
             $this->load->view('template');
         }

    }
	
	 function senaraiPengguna(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');	
			 $this->load->model('MPersonal');
			 $data['klien'] = $this->MPersonal->getPersonalByTahap('klien');		 
             $data['main'] ='pentadbir/senaraiPengguna';
	         $data['title'] ='Laman Utama Pentadbir';
			 $this->load->vars($data);
	        $this->load->view('template');
         }

    }
	 
	 function senaraiPetugas(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');	
			 $this->load->model('MPersonal');
			 $data['klien'] = $this->MPersonal->getPersonalByTahap('petugas');		 
             $data['main'] ='pentadbir/senaraiPetugas';
	         $data['title'] ='Laman Utama Pentadbir';
			 $this->load->vars($data);
	        $this->load->view('template');
         }

    }

	function senaraiPentadbir(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');	
			 $this->load->model('MPersonal');
			 $data['klien'] = $this->MPersonal->getPersonalByTahap('admin');		 
             $data['main'] ='pentadbir/senaraiPentadbir';
	         $data['title'] ='Laman Utama Pentadbir';
			 $this->load->vars($data);
	        $this->load->view('template');
         }

    }



}

<?php
class CFaqAdmin extends Controller{

    function CFaqAdmin(){
        parent::Controller();
        session_start();
       
    }

    function insert(){
    	if(!isset($_POST['papar'])){
			$papar = 0;
		}else{
			$papar = 1;
		}
        $data = array(
            'soalan'=>$_POST['soalan'],
            'jawapan'=>$_POST['jawapan'],
            'kategori'=>$_POST['kategori'],
            'sub_kategori'=>$_POST['sub_kategori'],
             'papar'=>$papar
          );
        $this->load->model('MFaq');
        $this->MFaq->insertFaq($data);
         redirect(base_url().'index.php/cfaq/','refresh');

    }
	
	function update($id_faq){
		if(!isset($_POST['papar'])){
			$papar = 0;
		}else{
			$papar = 1;
		}
		$data = array(
			'soalan'=>$_POST['soalan'],
            'jawapan'=>$_POST['jawapan'],
            'kategori'=>$_POST['kategori'],
            'sub_kategori'=>$_POST['sub_kategori'],
             'papar'=>$papar
          );
        $this->load->model('MFaq');
        $this->MFaq->updateFaq($id_faq,$data);
		redirect(base_url().'index.php/cfaq/','refresh');
	}

   function padamFaq($id_faq){
		 $this->load->model('MFaq');
		 $this->MFaq->padamFaq($id_faq);
		 
	}	

    function index(){
       if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
          $this->load->model('MKategori');
         $data['kat'] = $this->MKategori->getKategori();
        $data['main'] ='pentadbir/main_faq';
         $data['title'] ='utama_admin';
		 $data['menu'] = 'index';
         $this->load->vars($data);
        $this->load->view('template');
         }

    }

    function add_page(){
    	
       if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 //$this->load->library('form_validation');
			 
			// if($this->uri->segment(4) == ;
			$data['$id_faq'] = 'X';
			$data['action'] = 'add';
        	 $this->load->model('MKategori');
        	 $data['kat'] = $this->MKategori->getKategori();
             $data['title'] ='Knowledge Base';
             $data['main'] ='pentadbir/add_faq';
             $this->load->vars($data);
         	 $this->load->view('template');
         }
    }

	function updateFaq($id_faq = NULL){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->library('form_validation');
			 $this->load->helper('field');  
			 			 $data['action'] = 'edit';
         		$this->load->model('MKategori');
		  		$this->load->model('MFaq');
         		$data['kat'] = $this->MKategori->getKategori();
				//$data['sub_kat'] = $this->MKategori->getSubKategori($kod_kat);
				$data['faq'] = $this->MFaq->detailFaq($id_faq);
		 
            //$data['title'] ='Kemaskini artikel '.$data['faq']['soalan'];
            $data['title'] ='Kemaskini artikel ';
            $data['main'] ='pentadbir/add_faq';
             $this->load->vars($data);
          $this->load->view('template');
        }
		
	}
	
	function add_image(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
             $data['title'] ='Muat naik gambar Knowledge Base';
            $data['main'] ='upload_form';
             $this->load->vars($data);
          $this->load->view('template');
         }
	}

	function image_upload(){
	    if($this->my_ses->logged_in){
		$data['tahap'] = $this->session->userdata('tahap');
                $data['id'] = $this->session->userdata('id');
                $data['title'] ='Muat naik gambar Knowledge Base';
			
           //$config['upload_path'] = '/var/www/help_desk/uploads/'; // server directory
            $config['upload_path'] = 'C:\xampp\htdocs\help_desk\imagesfaq'; /* NB! create this dir! */
        //$config['upload_path'] = base_url().'uploads/'; // server directory
        $config['allowed_types'] = 'gif|jpg|png'; // by extension, will check for whether it is an image
        $config['max_size']    = '1000'; // in kb
        $config['max_width']  = '1024';
        $config['max_height']  = '768';
        
        $this->load->library('upload', $config);
        $this->load->library('Multi_upload');
    
        $files = $this->multi_upload->go_upload();
       //echo $config['upload_path'];exit;
     
            //$data = array('upload_data' => $files);
			

 //$this->session->set_flashdata('message', 'Anda telah berjaya memuatnaik fail.'); 

 			
           $data['main'] ='upload_form';
             $this->load->vars($data);
          $this->load->view('template');
        
         }
	}




}

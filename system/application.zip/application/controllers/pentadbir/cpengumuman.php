<?php
class CPengumuman extends Controller{

    function CPengumuman(){
        parent::Controller();
        session_start();
       
    }
	
	function index(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
         	 $this->load->model('MPengumuman');
         	 $data['pengumuman'] = $this->MPengumuman->senaraiPengumuman('0');
        	 $data['main'] ='pentadbir/senarai_pengumuman';
         	 $data['title'] ='Pengumuman';
		     $this->load->vars($data);
             $this->load->view('template');
		}
	}
	
	function new_pengumuman(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
          	 $data['main'] ='pentadbir/new_pengumuman';
             $data['title'] ='Tambah Pengumuman Baru';
			 $data['action'] = 'add';
		     $this->load->vars($data);
             $this->load->view('template');
         }

    }
	
	function kemaskini($id_pengumuman = NULL){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			 $this->load->model('MPengumuman');
          	 $data['main'] ='pentadbir/new_pengumuman';
             $data['title'] ='Tambah Pengumuman Baru';
			 $data['pengumuman'] = $this->MPengumuman->detailPengumuman($id_pengumuman);
			 $data['action'] = 'edit';
		     $this->load->vars($data);
             $this->load->view('template');
         }

    }
	
	
	
	function insert(){
		if($this->my_ses->logged_in){
             	$data['tahap'] = $this->session->userdata('tahap');
             	$data['id'] = $this->session->userdata('id');
				$papar = (isset($_POST['papar'])) ? "1": "0";
				$postdata = array(
		            'teks'=>$_POST['pengumuman'],
		            'papar'=>$papar,
		           'tarikh'=>date( 'Y-m-d H:i:s')
		          );
		        $this->load->model('MPengumuman');
		        $this->MPengumuman->insertPengumuman($postdata);
				$data['action'] = 'add';
				$data['main'] ='pentadbir/new_pengumuman';
	            $data['title'] ='Tambah Pengumuman Baru';
			    $this->load->vars($data);
	            $this->load->view('template');
        }

    }
	
	function update($id_Pengumuman){
		if($this->my_ses->logged_in){
             	$data['tahap'] = $this->session->userdata('tahap');
             	$data['id'] = $this->session->userdata('id');
		if(!isset($_POST['papar'])){
			$papar = 0;
		}else{
			$papar = 1;
		}
		$postdata = array(
		            'teks'=>$_POST['pengumuman'],
		            'papar'=>$papar,
		           'tarikh'=>date( 'Y-m-d H:i:s')
		          );
        $this->load->model('MPengumuman');
        $this->MPengumuman->updatePengumuman($id_Pengumuman,$postdata);
		 
			 $data['pengumuman'] = $this->MPengumuman->detailPengumuman($id_Pengumuman);
			 $data['action'] = 'edit';
				$data['main'] ='pentadbir/new_pengumuman';
	            $data['title'] ='Tambah Pengumuman Baru';
				$this->load->vars($data);
	            $this->load->view('template');
		}
	}

   function padamPengumuman($id_Pengumuman){
		 $this->load->model('MPengumuman');
		 $this->MPengumuman->padamPengumuman($id_Pengumuman);
		 
	}	
	



	
}
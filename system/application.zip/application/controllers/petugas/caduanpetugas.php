<?php
class CAduanPetugas extends Controller{

    function CAduanPetugas(){
        parent::Controller();
        session_start();
       $this->load->library('usertracking');
        $this->usertracking->track_this();
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'jab'=>$_POST['jab']
          );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);


    }

    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			
              $this->load->model('MAduan');
              $data['aduanbaru'] = $this->MAduan->getAduanDiagihByPegawaiKes($data['id']);
             $data['main'] ='petugas/senarai_aduan';
             $data['title'] ='Senarai Kes yang diterima';
             $this->load->vars($data);
             $this->load->view('template');
         }
    }
	
	function aduanDalamTindakan(){
		if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			
              $this->load->model('MAduan');
              $data['aduanbaru'] = $this->MAduan->getAduanDlmTindakanByPegawaiKes($data['id']);
             $data['main'] ='petugas/senarai_aduan';
             $data['title'] ='Senarai Kes yang diterima';
             $this->load->vars($data);
             $this->load->view('template');
         }
	}
	
	 function senaraiAgihan(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['nama'] = $this->session->userdata('nama');

              $this->load->model('MAduan');
              $data['aduanbaru'] = $this->MAduan->getAduanDiagih();
             $data['main'] ='pentadbir/senarai_aduan';
             $data['title'] ='Senarai Aduan Yang Telah Diagih';
             $this->load->vars($data);
             $this->load->view('template');
         }
    }
	
	function kemaskini($id_aduan){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['nama'] = $this->session->userdata('nama');

              $this->load->model('MAduan');
			  $this->load->model('MPersonal');
			  $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');
              $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
			   $data['personal'] = $this->MPersonal->getPersonal($data['butiran']['pegawai_kes']);
             $data['main'] ='pentadbir/butiran_aduan';
             $data['title'] ='Butiran Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
			
    }
	
	function kemaskiniAgihan($id_aduan){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['nama'] = $this->session->userdata('nama');

              $this->load->model('MAduan');
			  $this->load->model('MPersonal');
			  
			  $this->MAduan->updateAgihan($id_aduan);
             $data['main'] ='pentadbir/butiran_aduan';
			  $data['petugas'] = $this->MPersonal->getPersonalByTahap('petugas');
			  $data['butiran'] = $this->MAduan->butiranAduan($id_aduan);
			  $data['personal'] = $this->MPersonal->getPersonal($data['butiran']['pegawai_kes']);
			  
             $data['title'] ='Butiran Aduan Baru';
             $this->load->vars($data);
             $this->load->view('template');
         }
	}




}

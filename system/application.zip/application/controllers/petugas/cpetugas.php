<?php
class CPetugas extends Controller{

    function CPetugas(){
        parent::Controller();
        session_start();
		$this->load->library('usertracking');
        $this->usertracking->track_this();
       
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp'],
            'jab'=>$_POST['jab']
          );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);


    }

    function index(){
         if($this->my_ses->logged_in){
             $data['tahap'] = $this->session->userdata('tahap');
             $data['id'] = $this->session->userdata('id');
			  $this->load->model('MPengumuman');
         	 $data['pengumuman'] = $this->MPengumuman->senaraiPengumuman('1');
             $data['main'] ='petugas/utama_petugas';
	         $data['title'] ='Laman Utama Petugas';
	         $this->load->vars($data);
	         $this->load->view('template');
         }

    }




}

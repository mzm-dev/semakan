<?php
class CStaff_adm extends Controller {
    function CStaff_adm() {
        parent::Controller();
    }
    
    function insert() {
        $data = array (
            'nama'  => $_POST['nama'],
            'no_kp' => $_POST['no_kp'],
            'jab'   => $_POST['jab'],
            'bah'   => $_POST['bah'],
            'unit'  => $_POST['unit']
        );
        
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);
        $this->staff_list();
    }
    
    function update() {
        $data = array (
            'nama'  => $_POST['nama'],
            'no_kp' => $_POST['no_kp'],
            'jab'   => $_POST['jab'],
            'bah'   => $_POST['bah'],
            'unit'  => $_POST['unit']
        );
        
        $this->load->model('MPersonal');
        $this->MPersonal->updatePerson($data);
        $this->staff_list();
    }
    
    function delete() {
        
    }
    
    function search() {
        $this->load->view('staff/vstaff_reg', $data);
    }
    
    function staff_list() {
        $this->load->model('MPersonal');
        $data['staff'] = $this->MPersonal->getAllPerson();
        $this->load->view('staff/vstaff_list', $data);
    }
    
    function update_form($no_kp) {
        $this->load->model('MPersonal');
        $this->load->model('MJabatan');
        $data['person'] = $this->MPersonal->getPersonal($no_kp);
        $data['jab'] = $this->MJabatan->getJabatan();
        $this->load->view('staff/vstaff_reg', $data);
    }
    
    function reg_form() {
        $this->load->model('MJabatan');
        $data['jab'] = $this->MJabatan->getJabatan();
        $this->load->view('staff/vstaff_reg', $data);
    }
    
    function ajx_bah($kod_jab, $kod_bah) {
        $this->load->model('MJabatan');
        $bah = $this->MJabatan->getBahagian($kod_jab);
        $str = "<select id='bahagian' name='bah' onchange='get_unit()'> 
                    <option>--Sila Pilih--</option>";
        foreach ($bah as $row) {
            $s = $row['kod_bah'] == $kod_bah ? 'selected' : '';
            $str.= "<option value='".$row['kod_bah']."' ".$s.">".$row['ktrgn']."</option>";
        }
        $str .= "<select>";
        echo $str;
    }
    
    function ajx_unit($kod_bah, $kod_unit) {
        $this->load->model('MJabatan');
        $bah = $this->MJabatan->getUnit($kod_bah);
        $str = "<select name='unit'> 
                    <option>--Sila Pilih--</option>";
        foreach ($bah as $row) {
            $s = $row['kod_unit'] == $kod_unit ? 'selected' : '';
            $str.= "<option value='".$row['kod_unit']."' $s>".$row['ktrgn']."</option>";
        }
        
        $str .= "<select>";
        echo $str;
    }
}
?>

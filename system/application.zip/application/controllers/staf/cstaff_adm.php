<?php
class CStaff_Adm extends Controller{

    function CStaff_Adm(){
        parent::Controller();
    }

    function insert(){
        $data = array(
            'nama'=>$_POST['nama'],
            'no_kp'=>$_POST['no_kp']
        );
        $this->load->model('MPersonal');
        $this->MPersonal->insertPerson($data);
        

    }

    function update(){

    }

    function delete(){

    }

    function search(){
        
    }

    function reg_form(){
        $this->load->model('MJabatan');
        $data['jab'] = $this->MJabatan->getJabatan();
        $this->load->vars($data);
        $this->load->view('staf/vstaff_reg');
    }

    function ajx_bah($kod_jab){
        $this->load->model('MJabatan');
        $bah = $this->MJabatan->getBahagian($kod_jab);
        $str = "<select name=bahagian id=bahagian onchange=get_unit()>";
        $str .="<option>---Sila Pilih---</option>";
        foreach($bah as $row){
            $str.="<option value=".$row['kod_bah'].">".$row['ktrgn']."</option>";
        }
        $str.="</select>";
        echo $str;
    }

     function ajx_unit($kod_bah){
        $this->load->model('MJabatan');
        $bah = $this->MJabatan->getUnit($kod_bah);
        $str = "<select name=unit id=unit>";

        foreach($bah as $row){
            $str.="<option value=".$row['kod_unit'].">".$row['ktrgn']."</option>";
        }
        $str.="</select>";
        echo $str;
    }

}

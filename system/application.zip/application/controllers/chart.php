<?php

class Chart extends Controller {

    function Chart()
    {
        parent::Controller();
        $this->load->helper('url');
        $this->load->plugin('jpgraph');    
    }
    
    function index()
    {
        $data['title'] = "Using JpGraph from CodeIgniter 1.5";        
        $data['heading'] = "Example 0 in JpGraph 2.1.4";        
            
        // Setup Chart
        $ydata = array(11,3,8,12,5,1,9,13,5,7); // this should come from the model        
        $graph = linechart($ydata, 'This is a Line Chart');  // add more parameters to plugin function as required
        
        // File locations
        // Could possibly add to config file if necessary
        $graph_temp_directory = 'temp';  // in the webroot (add directory to .htaccess exclude)
        $graph_file_name = 'test.png';    
        
        $graph_file_location = $graph_temp_directory . '/' . $graph_file_name;
         
		@unlink($graph_file_location);
	//$graph->Stroke('st1_bar_chart.png');        
        $graph->Stroke('./'.$graph_file_location);  // create the graph and write to file
        //$graph->Stroke(base_url().$graph_file_location);  // create the graph and write to file
        
        $data['graph'] = $graph_file_location;
        
        $this->load->view('chart_view', $data);
    }
    
    function pie()
    {
        // Setup Chart
        $ydata = array(55,67,29); // this should come from the model        
        $graph = piechart($ydata, 'This is a Line Chart');  // add more parameters to plugin function as required
        
        // File locations
        // Could possibly add to config file if necessary
        $graph_temp_directory = 'temp';  // in the webroot (add directory to .htaccess exclude)
        $graph_file_name = 'test.png';    
        
        $graph_file_location = $graph_temp_directory . '/' . $graph_file_name;
         
		//@unlink($graph_file_location);
	//$graph->Stroke('st1_bar_chart.png');        
        $graph->Stroke('./'.$graph_file_location);  // create the graph and write to file
        //$graph->Stroke(base_url().$graph_file_location);  // create the graph and write to file
        $data['graph'] = $graph_file_location;
        
        //$this->load->view('chart_view', $data);
    }
}
?>
<?php
class CStaff extends Controller{

    function CStaff(){
        parent::Controller();
    }

    function staff_list(){
        $data = array();
        $this->load->model('MJabatan');
        $this->load->model('MPersonal');
        $data['jab'] = $this->MJabatan->getJabatan();
        $this->load->vars($data);
        $this->load->view('vstaff_list');

    }

    function search(){

    }

    function detail($no_kp){
        $data = array();
        $this->load->model('MPersonal');
        $data['person'] = $this->MPersonal->getPersonal($no_kp);
        $this->load->vars($data);
        $this->load->view('vstaff_detail');
        
    }

}


  <div id="chatbox"></div>  
   
     <form name="message" action="">  
         <input name="usermsg" type="text" id="usermsg" size="63" />  
         <input name="submitmsg" type="submit"  id="submitmsg" value="Send" />  
    </form>  
<h1>Status Aduan</h1>
<!--<div class="msgbar msg_Success hide_onC" style="">
<span class="iconsweet">=</span>
<p>This is a Success message.</p>
</div>-->
<form id="fm-form"  method="post" action="<?php echo base_url(); ?>index.php/caduan/butiranaduan">
 
 
</form>
<div class="content-box">
				<div class="box-header clear">
					<h2>Butiran Aduan : <?php echo $butiran['id']; ?></h2>
				</div>
				<div class="box-body clear">
					<form action="" method="post">
					<table class="jadual_butiran" width="100%">
					
					<tbody>
					<tr>
						<td class="title">Nama</td>
						<td class="full"><?php echo $butiran['nama']; ?></td>
			
					</tr>
					
					<tr>
						<td class="title">Perkara</td>
						<td ><p><?php echo $butiran['perkara']; ?></p></td>
						
					</tr>
					<tr>
						<td class="title">Keterangan</td>
						<td ><p><?php echo $butiran['keterangan']; ?></p></td>
						
					</tr>
					<tr>
						<td class="title">Status</td>
						<td class="edit-field edit-select"><?php echo $butiran['status']; ?></td>
					
					</tr>
					<tr>
						<td class="title">Keutamaan</td>
						<td class="edit-field edit-date"><?php echo $butiran['keutamaan']; ?></td>
						
					</tr>
					<tr>
						<td class="title">Tarikh Aduan</td>
						<td class="edit-field edit-date"><?php echo unix_ke_malaysia(mysql_to_unix($butiran['tarikh_aduan'])); ?>
							</td>
					
					</tr>
					<?php if($butiran['status'] != "Baru"){ ?>
                                        <tr>
						<td class="title">Pegawai Kes</td>
						<td class="edit-field edit-date"><?php echo $this->MPersonal->getNama($butiran['pegawai_kes']); ?>
							</td>
					
					</tr>
					<?php } ?>
					<tr>
						<td class="title">Lampiran</td>
						<td >
							<a href="<?php echo base_url(); ?>uploads/<?php echo $butiran['lampiran1']; ?>">
								<?php echo $butiran['lampiran1']; ?>
							</a>
								
							</td>
					
					</tr>
					
					</tbody>
					</table>
					<?php if(($butiran['status'] == "Diagih") && ($butiran['status'] != "Baru") && ($tahap == 'petugas')){ ?>
					<p align="center">
								<div id="butang_tambah">
									Terima kes ini? <a href="<?php echo base_url(); ?>index.php/pentadbir/caduanadmin/terima/<?php echo $butiran['id']; ?>">Terima</a>
								</div></p>
					<?php } ?>
					</form>
					
				</div> <!-- end of box-body -->
			</div>
<?php if($tahap == "admin"){ ?>
<div class="content-box">
                    <div class="box-header clear">
                            <h2>Agihan</h2>
                    </div>

            <div class="box-body clear">
                  <form id="fm-form"  method="post"
action="<?php echo base_url(); ?>index.php/pentadbir/caduanadmin/kemaskiniAgihan/<?php echo $butiran['id']; ?>">
                <div id="forms" style="display: block;">
                <div class="form-field clear">
                    <label >Diagihkan kepada</label>
                     <select name="pegawai_kes" id="pegawai_kes">
                        <option>---Sila Pilih---</option>                                  
                         <?php foreach($petugas as $row){?>
                	<?php 
                        if(($butiran['pegawai_kes']!='') && ($butiran['pegawai_kes'] == $row['no_kp'])){ 
                 	$selected="selected='selected'";					
                            }else{
                                 $selected="";	  
                           }?>
                        <option <?php echo $selected; ?> value="<?php echo $row['no_kp']; ?>">
                        <?php echo $row['nama']; ?>
                        </option>
                         <?php $selected="";		
                                        }?>
                 </select>
                </div>
                </div>
                <div id="fm-submit" class="fm-req">
                    <input name="Submit" value="Hantar" type="submit" />
                     <input name="Reset" value="Reset" type="reset" />
                    <input name="Batal" value="Batal" type="reset" />
                    <input type="hidden" name="id_pengagih" value="<?php echo $id; ?>"/>
                </div>
                  </form>
        </div> <!-- end of box-body -->
              
			</div>
        <?php } ?>
<?php if($butiran['status'] != 'Baru'){ ?>
<div class="content-box">
				<div class="box-header clear">
					<h2>Maklumbalas</h2>
				</div>
              		<div class="box-body clear">
                                      <?php foreach($sen_mklmbls as $senarai){ ?>
					<table class="jadual_butiran" width="100%">
					
					<tbody>
					
					<tr>
						<td class="title">Dibalas oleh <?php 
                                                $nama = $this->MPersonal->getNama($senarai['no_kp']);
                                                echo $nama; ?><br />
                         pada                   <?php echo unix_ke_malaysia(mysql_to_unix($senarai['tarikh_mklm_bls'])); ?></td>
						
						
					</tr>
					<tr>
						
						<td class="full"><?php echo $senarai['kandungan']; ?></td>
						
					</tr></tbody>
					</table>
				 <?php } ?> 	
				</div>
               <!-- end of box-body -->
			</div>
          
   <?php   
   if(($butiran['status'] != "Selesai")){?>         
            <div class="content-box">
				<div class="box-header clear">
					<h2>Tulis Maklumbalas</h2>
				</div>
				<div class="box-body clear">
			<form method="post" 
action="<?php echo base_url(); ?>index.php/caduan/maklumbalasAduan/<?php echo $butiran['id']; ?>">
                <div id="forms" style="display: block;">
                <div class="form-field clear">
                   <textarea rows="10" name="kandungan_mklmbls" style="width:100%"></textarea>                     
                </div>
                <div class="form-field clear">
                 	<img src="<?php echo base_url();?>images/first.gif"> Lampiran
                 	
                          <input type="file" name="lampiran" size="50"  >
                          
                               
                </div>
                 <div class="form-field clear">
                 	Selesai?
                  <input type="checkbox" name="status" value="1">                   
                </div>
                </div>
                <div id="fm-submit" class="fm-req">
                    <input name="Submit" value="Hantar" type="submit" />
                     <input name="Reset" value="Reset" type="reset" />
                     <input type="hidden" name="id_pengagih" value="<?php echo $id; ?>"/>
                </div>
                  </form>
				</div> <!-- end of box-body -->
				
			</div>
<? } 

}?>
<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>
<h1>Artikel Knowledge Base</h1>
  <div class="content-box">
				<div class="box-header clear">
										
					<h2><?php echo $faq['soalan']; ?></h2>
				</div>
				
				<div class="box-body clear">
	
		<!--	Nilaikan Artikel Ini :-<br />
<form method="post" class="borang"   action="<?php echo base_url(); ?>index.php/cfaq/updaterating">

<input name="star1" type="radio" class="star" value="1"/>
<input name="star1" type="radio" class="star" value="2"/>
<input name="star1" type="radio" class="star" value="3"/>
<input name="star1" type="radio" class="star" value="4"/>
<input name="star1" type="radio" class="star" value="5"/>

<input type="submit" value="Nilai" />

</form> 
<div id="maklumat_artikel">Rating: 4/5 | Tarikh artikel dikemaskini:</div>-->
<div id="kandungan_artikel"><?php echo $faq['jawapan']; ?></div>

				</div> <!-- end of box-body -->
</div> 
 <div class="content-box">
				<div class="box-header clear">
										
					<h2>Penilaian Artikel</h2>
				</div>
				
				<div class="box-body clear">
	
			<!-- Custom Forms -->
			<div id="forms" style="display: block;">
				<!--<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/cfaq/nilaiFaq" enctype="multipart/form-data">-->  
				<div class="form-field clear">
					<input type="hidden" value="<?php echo str_replace(' ', '_', $katakunci); ?>" id="katakunci"/>
					<div id="senarai_berkaitan">
					
					Adakan artikel ini membantu anda?
					<input name="Ya" value="Ya" type="submit" onclick="terimaKasih()"/>
					<input name="Tidak" value="Tidak" type="submit" onclick="getList()"/></div>
       				</div><!-- /.form-field -->
				<!--</form> -->
      
				</div> <!-- end of box-body -->
</div>
</div>
   


<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/star_rating/jquery.rating.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/star_rating/jquery.rating.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    	function terimaKasih(){
    	$('#senarai_berkaitan').load('<?php echo base_url();?>index.php/cfaq/ajx_terimaKasih/');	
    	}
    	
    	function getList(){
		var katakunci = $('#katakunci').val();
		if(katakunci != ''){
		$('#senarai_berkaitan').load('<?php echo base_url();?>index.php/cfaq/ajx_getList/'+katakunci);
		}
		}
</script>
<h2>Senarai Aduan</h2>
<table class="jadualh" width="70%" border="1">
<thead>
	<th>ID</th>
	<th>Tarikh Aduan</th>
	<th>Nama</th>
	<th>Keutamaan</th>
	<th>Isu</th>
	<th>Tindakan</th>
</thead>

<?php foreach($aduanbaru as $row){?>
<tr>
	<td><?php echo $row['id'] ?></td>
	<td><?php echo unix_ke_malaysia(mysql_to_unix($row['tarikh_aduan'])); ?></td>
	<td><?php echo $row['nama'] ?></td>
	<td><?php echo $this->MAduan->getKeutamaan($row['keutamaan']); ?></td>
	<td><?php echo $row['perkara'] ?></td>
	<td>
	<a href="<?php echo base_url();?>index.php/pentadbir/caduanadmin/kemaskini/<?php echo $row['id'];?>"><img src="<?php echo base_url(); ?>images/update.png" border="0"></a> 
	<a href="<?php echo $row['id'] ?>" class="deleteAduan" >
        	<img src="<?php echo base_url(); ?>images/delete.png" border="0"></a>	
	</td>
</tr>
<?php } ?>
</table>

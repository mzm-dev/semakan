<h1>Status Aduan</h1>
<!--<div class="msgbar msg_Success hide_onC" style="">
<span class="iconsweet">=</span>
<p>This is a Success message.</p>
</div>-->
<form id="fm-form"  method="post" action="<?php echo base_url(); ?>index.php/caduan/butiranaduan">
 
 
</form>
<div class="content-box">
				<div class="box-header clear">
					<h2>Butiran Aduan : <?php echo $butiran['id']; ?></h2>
				</div>
				<div class="box-body clear">
					<form action="" method="post">
					<table class="jadual_butiran" width="100%">
					
					<tbody>
					<tr>
						<td class="title">Nama</td>
						<td class="full"><?php echo $butiran['nama']; ?></td>
			
					</tr>
					
					<tr>
						<td class="title">Perkara</td>
						<td ><p><?php echo $butiran['perkara']; ?></p></td>
						
					</tr>
					<tr>
						<td class="title">Keterangan</td>
						<td ><p><?php echo $butiran['keterangan']; ?></p></td>
						
					</tr>
					<tr>
						<td class="title">Status</td>
						<td class="edit-field edit-select"><?php echo $butiran['status']; ?></td>
					
					</tr>
					<tr>
						<td class="title">Keutamaan</td>
						<td class="edit-field edit-date"><?php echo $butiran['keutamaan']; ?></td>
						
					</tr>
					<tr>
						<td class="title">Tarikh Aduan</td>
						<td class="edit-field edit-date"><?php echo unix_ke_malaysia(mysql_to_unix($butiran['tarikh_aduan'])); ?>
							</td>
					
					</tr>
					<tr>
						<td class="title">Lampiran</td>
						<td >
							<a href="<?php echo base_url(); ?>uploads/<?php echo $butiran['lampiran1']; ?>">
								<?php echo $butiran['lampiran1']; ?>
							</a>
								
							</td>
					
					</tr>
					</tbody>
					</table>
					
					
					</form>
					
				</div> <!-- end of box-body -->
			</div>

<div class="content-box">
				<div class="box-header clear">
					<h2>Maklumbalas</h2>
				</div>
                <?php foreach($sen_mklmbls as $senarai){ ?>
				<div class="box-body clear">
					<table class="jadual_butiran" width="100%">
					
					<tbody>
					
					<tr>
						<td class="title">Dibalas oleh <?php echo $senarai['nama']; ?><br />
                         pada <?php echo unix_ke_malaysia(mysql_to_unix($senarai['tarikh_mklm_bls'])); ?></td>
						
						
					</tr>
					<tr>
						
						<td class="full"><?php echo $senarai['kandungan']; ?></td>
						
					</tr></tbody>
					</table>
					
				</div>
                <?php } ?> <!-- end of box-body -->
			</div>
            
            <div class="content-box">
				<div class="box-header clear">
					<h2>Tulis Maklumbalas</h2>
				</div>
				<div class="box-body clear">
					<form method="post" 
action="<?php echo base_url(); ?>index.php/caduan/maklumbalasAduan">
<input type="hidden" name="id_aduan" value="<?php echo $butiran['id']; ?>" />
<input type="hidden" name="pembalas" value="<?php echo $butiran['nama']; ?>" />
					<table class="jadual_butiran" width="100%">
					
					<tbody>
					<tr>
                    <td><textarea rows="10" name="kandungan_mklmbls" style="width:100%"></textarea></td>
                    </tr>
                     <tr>
    				<td><span class="normaltext"><img src="<?php echo base_url();?>images/first.gif"> <strong> Lampiran: </strong>
                          <input type="file" name="lampiran" size="50"  >
                          </span>

                      <p>
                        <span class="normaltext">
                        <input type="submit"      value="Post Reply" name="B1" ></span></p>
                        </td>
         				</tr>
					</tbody>
					</table>
					
					
					</form>
					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>
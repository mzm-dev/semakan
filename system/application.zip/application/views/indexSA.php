<h1>Status Aduan</h1>

<div class="content-box">
				<div class="box-header clear">
										
					<h2>Carian Status Aduan</h2>
				</div>
				
				<div class="box-body clear">
	
			<!-- Custom Forms -->
			<div id="forms" style="display: block;">				     
        
        <h4>Sila pilih aduan anda daripada senarai di bawah atau masukkan ID aduan.</h4>
        <form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/caduan/cariAduan" enctype="multipart/form-data">  
				<div class="form-field clear">
                                    <label>ID aduan</label>
					<input type="text" name="id_aduan"  size="10" maxlength="10" value=""  /> <input name="Cari" value="Cari" type="submit" />
       				</div><!-- /.form-field -->
				</form>
	<table class="jadualh" width="80%" border="1">
            <thead>
                    <th>ID Aduan</th>
                    <th>Tajuk Aduan</th>
                    <th>Tarikh Aduan</th>
                    <th>Status</th>
                    <th>Pegawai Kes</th>
                    <th>Tindakan</th>
            </thead>
        <?php foreach($senarai as $item){?>
        <tr id="tr<?php echo $item['id'] ?>">
        <td><?php echo $item['id'] ?></td>
        <td><?php echo $item['perkara'] ?></td>
        <td><?php echo $item['tarikh_aduan'] ?></td>
        <td><?php echo $item['status'] ?></td>
        <td><?php echo $item['pegawai_kes'] != '' ? $this->MPersonal->getNama($item['pegawai_kes']): '-'; ?></td>
        <td><a href="<?php echo base_url(); ?>index.php/caduan/butiranAduan/<?php echo $item['id']; ?>">
        	<img src="<?php echo base_url(); ?>images/view.png" border="0"></a>
        <a href="<?php echo $item['id'] ?>" class="deleteAduan" >
        	<img src="<?php echo base_url(); ?>images/delete.png" border="0"></a>	
        </td>
        </tr>
        <?php } ?>
            </table>	

				</div> <!-- end of box-body -->
</div>
    <br>				
		
</div>
<!-- dialog box -->
        <div class="deleteConfirm" title="Pengesahan">
            <p>Anda pasti untuk memadam kes ini?</p>
             
        </div>
 <!-- end dialog box -->


<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">		
	$(document).ready(function(){
    var id;
    $('.deleteAduan').click(function(e){
       id = $(this).attr('href');
       $('.deleteConfirm').dialog('open');
       
       e.preventDefault();
    })
    $('.deleteConfirm').dialog({
        autoOpen : false,
        modal : true,
        buttons : {
              'Yes' : function(){
               $.ajax({
               	   type: "POST",
                   url : 'caduan/padamAduan/' + id,
                   success : function(){
                       // i must remove the div
                       $('.deleteConfirm').dialog('close');
                       $('#tr' + id).slideUp(1000);
                   }
               })
            },
            'No' : function(){
                $(this).dialog('close');
            }
        }
    })
})
</script>
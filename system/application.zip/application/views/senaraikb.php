<h1>Senarai Knowledge Base</h1>
<table class="jadualh" width="80%" border="1">
<thead>
	
	<th width="150">Kategori</th>
	<th width="500">Tajuk</th>	
	<th width="80">Tindakan</th>
</thead>

<?php foreach($senarai as $row){?>
<tr>
	
	<td><?php echo $this->MKategori->getNamaKategori($row['kategori']); ?>
            <br/>-&nbsp;<?php 
			if($row['sub_kategori'] != 0){
				echo $this->MKategori->getNamaSubKategori($row['sub_kategori']);
						  }?></td>
	<td><?php echo $row['soalan'] ?></td>
	  <td><a href="<?php echo base_url(); ?>index.php/cfaq/detailFaq/<?php echo $row['id']; ?>">
                  <img src="<?php echo base_url(); ?>images/view.png" border="0"></a></td>
	
</tr>
<?php } ?>
</table>

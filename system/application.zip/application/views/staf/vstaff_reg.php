<form method="post" action="<?php echo base_url(); ?>index.php/staf/cstaff_adm/insert">
<table>
    <tr>
        <td>No Kp</td>
         <td><input type="text" name="no_kp"></td>
    </tr>
    <tr>
        <td>Nama</td>
         <td><input type="text" name="nama"></td>
    </tr>
     <tr>
        <td>Jabatan</td>
         <td><select name="jab" id="jab" onchange="get_bah()">
                 <option>---Sila Pilih---</option>
                 <?php foreach($jab as $jabatan){ ?>
                <option value="<?php echo $jabatan['kod']; ?>"><?php echo $jabatan['ktrgn']; ?></option>
          <?php } ?>
             </select>
        </td>
    </tr>
     <tr>
        <td>Bahagian</td>
         <td><span id="bah"></span>
        </td>
    </tr>
     <tr>
        <td>Unit</td>
         <td><span id="unit"></span>
        </td>
    </tr>
     <tr>
         <td>&nbsp;</td>
         <td><input type="submit" value="Simpan"></td>
    </tr>
</table>
</form>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/smoothness/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_bah(){
        var kod_jab = $('#jab').val();
        //alert(kod_jab);
        $('#bah').load('<?php echo base_url();?>index.php/staf/cstaff_adm/ajx_bah/'+kod_jab);
    }

    function get_unit(){
        var kod_bah = $('#bahagian').val();
        $('#unit').load('<?php echo base_url();?>index.php/staf/cstaff_adm/ajx_unit/'+kod_bah);
    }
</script>
<h1>Home</h1>
<a href="<?php echo base_url();?>index.php/clogin/logout">logout</a>
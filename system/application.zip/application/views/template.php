<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/layout.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/form.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jadual.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/nav.css" />
       <!-- <script type="text/javascript" src="<?php echo base_url(); ?>js/tinymce/jscripts/tiny_mce/tiny_mce.js" >
            </script> -->
        
        
</head>
<body>

	<div id="container">

		<div id="header">
                    <?php //echo $tahap; ?>
			<h1>Sistem Help Desk Generik</h1>
                        Selamat Datang
                         <?php 
                         $nama = $this->MPersonal->getNama($id);
                         echo $nama.'</br>';
                        ?>
                        <br>
                        <form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/cfaq/carianFaqMain"" enctype="multipart/form-data"> 
                      <input type="text" name="perkara" id="autocomplete" size="40" maxlength="40" value=""  /> <input name="Cari" value="Cari" type="submit" /> 
            			</form>
             </div>
             <?php 
                    if($tahap == 'admin'){ 
                     $this-> load-> view('admin_navigation');
                    }
                    if($tahap == 'klien'){ 
                     $this-> load-> view('user_navigation');
                    }
                    if($tahap == 'petugas'){ 
                     $this-> load-> view('petugas_navigation');
                    }
               ?>
               

		<div id="content">
			<?php 
			if($tahap == 'klien'){
			$this-> load-> view('pagechat');
			} ?>
			<?php $this-> load-> view($main);?>
		</div>

		<div id="footer">
                    <p>Hak Cipta Terpelihara</p>
		</div>
	</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<!--<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css"> 


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>-->
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function() {
	    $(function() {
	        $( "#autocomplete" ).autocomplete({
	            source: function(request, response,event,ui) {
	                $.ajax({ url: "<?php echo base_url();?>index.php/caduan/json_zip",
	                data: { term: $("#autocomplete").val()},
	                dataType: "json",
	                type: "POST",
	                success: function(data){
	                    //response(data);
	                     response($.map(data.message,function(c){
	                     	
	                     	return {
	                     		value : c.label,
	                     		id:c.value
	                     		}
	                    	 }
	                  ))  //<--- end of response
	                  	
                           }
                      });
                   
	        },
	        minLength: 2,
              select: function(event, ui){
              	
              	location.href = "<?php echo base_url();?>index.php/cfaq/detailfaq/"+ui.item.id;
              }  
                
	        });
	    });
	});

		
		
	</script>
	</html>
	

</body>
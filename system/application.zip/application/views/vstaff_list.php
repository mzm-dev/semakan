<ul id="jab" class="L1">
    <?
    //$this->load->model('MJabatan');
    //$this->load->model('MPersonal');
    
    foreach($jab as $row) {
        $bah = $this->MJabatan->getBahagian($row['kod']);
    ?>
        <li>
            <?=$row['ktrgn']?>
            <ul class='L2'>
                <? 
                foreach($bah as $row2) { 
                    $unit = $this->MJabatan->getUnit($row2['kod_bah']);
                ?>
                    <li>
                        <?=$row2['ktrgn']?>
                        <ul class='L3'>
                        <?
                        foreach($unit as $row3) { 
                            $person = $this->MPersonal->getPersonalByUnit($row3['kod_unit']);
                        ?>
                            <li>
                                <?=$row3['ktrgn']?>
                                <ul class='L4'>
                                    <?
                                    foreach($person as $row4) {
                                    ?>
                                        <li onclick="get_person('<?=$row4['no_kp']?>')"><?=$row4['nama']?></li>
                                 <? } ?>
                                </ul>
                            </li>
                     <? } ?>
                        </ul>
                    </li>
             <? } ?>
            </ul>
        </li>
        
    <? 
    } 
    ?>
</ul>

<!--- POPUP DIALOG --->
<div id="person" style="display:none">
    
</div>

<link rel="stylesheet" href="<?=base_url()?>js/jqueryui/css/ui-lightness/jquery-ui-1.8.18.custom.css" />
<link rel="stylesheet" href="<?=base_url()?>js/treeview/jquery.treeview.css" />
<link rel="stylesheet" href="<?=base_url()?>js/treeview/mytree.css" />

<script src="<?=base_url()?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?=base_url()?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?=base_url()?>js/treeview/jquery.treeview.js" type="text/javascript"></script>

<script src="<?=base_url()?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<!--<script src="<?=base_url()?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>-->

<script>
$('#jab').treeview();

function get_person(no_kp) {
    // call using AJAX
    $('#person').dialog({title:'Maklumat Terpeinci Staf'});
    $('#person').load('<?=base_url()?>index.php/cstaff/detail/'+no_kp);
}
</script>
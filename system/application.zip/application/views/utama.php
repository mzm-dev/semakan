<h1>Laman Utama</h1>
<div id="leftcolumn">
	Selamat Datang ke Sistem Help Desk Generik.
	
</div>

<div id="rightcolumn">
    <div class="content-box">
				<div class="box-header clear">
										
					<h2>Pengumuman</h2>
				</div>
				
				<div class="box-body clear">
                                     <div class="newsticker">
                                        <ul>
                                        <?php foreach($pengumuman as $row){ ?>
                                        <li><?php echo $row['teks']?><br/>
                                        	<?php echo unix_ke_tarikh(mysql_to_unix($row['tarikh'])); ?></li>                                        
                                       <?php } ?>
                                        </ul>
                                     </div>
					
				</div> <!-- end of box-body -->
			</div>

    
</div>
<!--<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>-->

<script src="<?php echo base_url();?>js/ticker.js" type="text/javascript"></script> 


<script type="text/javascript">
$(document).ready(function() {
	   $('.newsticker').vTicker({
            speed: 500,
            pause: 3000,
            showItems: 2,
            animation: 'fade',
            mousePause: false,
            height: 0,
            direction: 'up'
            });
	});

		
		
	</script>
 <div id="page-subheader">
               
            <nav id="sub-nav">
                        <ul>
                        	<?php
                        	 if($tahap == 'admin'){ ?>
                        <li class="active"> <a href="<?php echo base_url(); ?>index.php/pentadbir/cadmin">Laman Utama</a></li>
                         <?php }elseif($tahap == 'petugas'){ ?>
                         <li class="active"><a href="<?php echo base_url(); ?>index.php/petugas/cpetugas">Laman Utama</a></li>
                         <?php }else{ ?>
                        <li class="active"><a href="<?php echo base_url(); ?>index.php/clogin">Laman Utama</a></li>
                        <?php } ?>
                        	
                           
                          
                            <li><a href="<?php echo base_url();?>index.php/cinteract">Interaksi</a></li>
                            
                        </ul>
                    </nav>
                  <span ><a class="logout" href="<?php echo base_url(); ?>index.php/clogin/logout">Log Keluar</a></span>
                    </div>
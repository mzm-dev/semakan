<!DOCTYPE html>
<html>
<head>
<title><?php echo $title; ?></title>
<meta charset="utf-8" />
<style>
body {
	margin: 0;
	padding: 0;
	background: #fff;
	color: #000;
	font: 76% Tahoma, sans-serif;
}

h1, h2, h3, h4, h5, h6, ul, form, p {
	margin: 0;
	padding: 0;
	font-size: 100%;
	font-weight: normal;
	list-style: none;
}

#site {
	width: 100%;
	font-size: 1.1em;
	background: url(../../images/bg.gif) repeat-x;
}

#content {
	width: 70%;
	margin: 0 auto;
	height: 100%;
	overflow: hidden;
}

#main {
	float: left;
	width: 78%;
	border-right: 1px solid #999;
	border-left: 1px solid #999;
	border-bottom: 1px solid #999;
}

#aside {
	float: left;
	width: 20%;
}

#aside h1 {
	background: #000;
	height: 26px;
	padding-left: 0.5em;
	line-height: 26px;
	font-weight: bold;
	color: #fff;
}

#aside h3 {
	margin: 1em 0 0 0;
	background: silver;
	padding: 4px;
	font-weight: bold;
}

#aside ul {
	margin: 1em 0;
	line-height: 1.4;
}

#search-nav {
	background: #999;
	color: #fff;
	height: 26px;
}

#search-nav form {
	float: left;
	height: 100%;
	line-height: 26px;
	padding-left: 0.3em;
}

#search-nav form #q {
	width: 200px;
	background: #fff;
	font: 1em Tahoma, sans-serif;
	border: none;
}

#search-nav form #submit {
	background: transparent;
	border: none;
	font: 1em Tahoma, sans-serif;
	position: relative;
	left: -5em;
}

#search-nav ul {
	float: right;
	height: 26px;
}

#search-nav ul li {
	float: left;
	height: 100%;
	margin-right: 0.5em;
}

#search-nav ul li.nav-last {
	margin-right: 0;
}

#search-nav ul li a {
	float: left;
	display: block;
	height: 100%;
	line-height: 26px;
	padding: 0 1em;
	color: #fff;
	text-decoration: none;
	font-weight: bold;
}

#search-nav ul li a:hover {
	background: #888;
}

#main-content {
	height: 100%;
	overflow: hidden;
}

#main-content-left {
	float: left;
	width: 68%;
}

#main-content-right {
	float: right;
	width: 28%;
}

#main-menu {
	height: 2em;
	background: silver;
	margin: 1em auto;
	padding-left: 0.5em;
	width: 90%;
}

#main-menu li {
	height: 100%;
	line-height: 2;
	margin-right: 0.5em;
	float: left;
}

#main-content p {
	line-height: 1.3;
	margin: 0.5em auto;
	width: 90%;
}

#main-content-right {
	padding-top: 1em;
}

#main-content-right h3 {
	background: silver;
	padding: 4px;
	font-weight: bold;
}

#footer {
	height: 26px;
	font-size: 0.85em;
	width: 80%;
	float: right;
}

address {
	float: left;
	height: 100%;
	font-style: normal;
	line-height: 26px;
}

#footer ul {
	float: right;
	height: 100%;
	padding-right: 1em;
}

#footer ul li {
	float: left;
	height: 100%;
	line-height: 26px;
	margin-right: 0.5em;
}
</style>
</head>

<body>

<div id="site">
	<div id="content">
	<div id="aside">


		  <h1>Site Name</h1>

		  <h3>News</h3>

		  <ul id="news">
		  	<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>

					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
		  </ul>

		</div>

		<div id="main">

			<div id="search-nav">

				<form id="search" method="get" action="#">
				  <div>
				  	<input type="text" name="q" id="q" />
				  	<input type="submit" id="submit" name="submit" value="Search" />
				  </div>
				</form>
				<ul id="nav">
                                    <?php echo $logmasuk['nama']; ?>
					<li><a href="#">Link</a></li>

					<li><a href="#">Link</a></li>
					<li class="nav-last"><a href="#">Link</a></li>
				</ul>
			</div>

			<div id="main-content">

			  <div id="main-content-left">

			     <ul id="main-menu">

			        <li><a href="#">Link</a></li>

					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>
					<li><a href="#">Link</a></li>

			     </ul>


			     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>




			  </div>

			  <div id="main-content-right">

			    <h3>Lorem ipsum</h3>

			    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

 				<h3>Lorem ipsum</h3>


 				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>




			  </div>

		   </div>


		</div>
		<div id="footer">

			  <address>Site Name</address>

			  <ul>
			  	<li><a href="#">Link</a></li>

			  	<li><a href="#">Link</a></li>
			  	<li><a href="#">Link</a></li>
			  </ul>

			</div>

</div>

</div>


</body>

</html>
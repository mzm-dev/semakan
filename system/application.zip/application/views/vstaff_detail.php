<?php
//print_r ($person);
?>

<table border="1">
    <tr>
        <td>Nama</td>
        <td>:<?=$person['nama']?></td>
        <td>Emel</td>
        <td>:<?=$person['emel']?></td>
    </tr>
</table>
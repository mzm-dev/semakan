<?php
//session_start();
$me = $id;
$_SESSION['username'] = $me; // Must be already set

//echo $_SESSION['username'];
?>
<style type="text/css">
        

        .head
        {
            float: left;
            display: block;
            width: 100%;
        }

        

       
         small
        {
            font-size: 8px;
        }

        h2
        {
            margin:0;
            color: #333;
            float: left;
        }
        a
        {
            font-size: 12px;
            text-decoration: none;
        }
        #red
        {
            color: #f00;
            width: 100%;
            font-size: 12px;
        }
    </style>

    <h1>Interaksi(Chat)</h1>

<div class="content-box">
	<?php if($tahap != "petugas"){ ?>
				<div class="box-header clear">
										
					<h2>Senarai Petugas Yang Berada di Dalam Talian</h2>
				</div>
				
				<div class="box-body clear">
							                    			
					<div class="box_c_content">
						<ul class="chatter_list">
							<?php foreach($petugas->result_array() as $pet){ ?>
						    <li>
						    <!--<a href="<?php echo base_url()?>index.php/cinteract/chat/<?php echo $id;?>/<?php echo $pet['no_kp']; ?>">
			                <span class="ov_nb">Chat(You with <?php echo $pet['no_kp']; ?>)</span></a>-->
			                 <a href="javascript:void(0)" onclick="javascript:chatWith('<?php echo $pet['no_kp']; ?>')">
			                 	<span class="ov_nb">Chat With <?php echo $pet['no_kp']; ?></span></a>
			                </li>
						      <?php } ?> 
						</ul>
					</div>
				</div>
  	<?php } ?>
		
</div>



<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">
<link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url();?>chat/css/chat.css" />



<script src="<?php echo base_url();?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>chat/js/chat.js"></script>


       
   

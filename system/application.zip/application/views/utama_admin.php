<h1>Laman Utama Pentadbir</h1>
<ul>
    <li><a href="<?php base_url();?>caduanadmin">Senarai Aduan Baru</a></li>
    <li><a href="<?php base_url();?>caduanadmin/senaraiAgihan">Senarai Aduan Yang Sudah Diagih</a></li>
	 <li><a href="<?php base_url();?>cfaqadmin">FAQ</a></li>
</ul>
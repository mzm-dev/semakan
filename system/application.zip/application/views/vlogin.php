<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>Muka Depan</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/layout.css" type="text/css" media="screen" />
	
</head>

<br><div id="login_form">
	<?php
if(isset($success)){ ?>
<div class="success">
		<p><?php echo $success; ?></p>
</div>	
<?php } ?>
	<?php
if(isset($login_failed)){ ?>
<div class="error">
		<p><?php echo $login_failed; ?></p>
</div>	
<?php } ?>
	<h1>Log Masuk</h1>
<form method="post" action="<?php echo base_url(); ?>index.php/clogin/login">
     <label>ID Pengguna:</label>
            <input type="text" name="no_kp">
        <label>Kata Laluan:</label>
       <input type="password" name="katalaluan">

<input type="submit" value="Log Masuk">
<input type="reset" value="Batal">
<p>
<div id="butang_tambah">
	Belum mendaftar?
	<a href="<?php echo base_url(); ?>index.php/clogin/pendaftaran">Pendaftaran</a>
</div></p>
</form>
</div>



</body>
</html>
<table border="1" width="50%">
    <tr bgcolor="silver">
        <td>#</td>
        <td>Nama</td>
        <td></td>
    </tr>
    <?
    $i = 1;
    foreach ($staff as $row) {
    ?>
        <tr>
            <td><?=$i++?>.</td>
            <td><?=$row['nama']?></td>
            <td><a href="<?=base_url()?>/index.php/staff/cstaff_adm/update_form/<?=$row['no_kp']?>">Edit</a></td>
        </tr>
    <?
    }
    ?>
</table>
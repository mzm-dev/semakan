<?
if (isset($person['no_kp'])) {
    $u = true; // u = update
    $action = "update";
} else {
    $u = false;
    $action = "insert";
}
?>

<form method="post" action="<?=base_url()?>index.php/staff/cstaff_adm/<?=$action?>">
<table>
    <tr>
        <td>No KP</td>
        <td><input type="text" name="no_kp" value="<?= $u ? $person['no_kp'] : ''?>" /></td>
    </tr>
    <tr>
        <td>Nama</td>
        <td><input type="text" name="nama" value="<?=isset($person['nama']) ? $person['nama'] : ''?>" /></td>
    </tr>
    <tr>
        <td>Jabatan</td>
        <td>
            <select id="jab" name="jab" onchange="get_bah()">
                <option>--Sila Pilih--</option>
                <?
                $val = $u ? $person['jab'] : '';
                foreach ($jab as $row) { ?>
                    <option value="<?=$row['kod']?>" <?=$row['kod'] == $val ? 'selected' : ''?>><?=$row['ktrgn']?></option>
                <?
                } 
                ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Bahagian</td>
        <td>
            <span id="bah"></span>
        </td>
    </tr>
    <tr>
        <td>Unit</td>
        <td>
            <span id="unit"></span>
        </td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" value="Simpan" /></td>
    </tr>
</table>
</form>

<script src="<?=base_url()?>js/jqueryui/js/jquery-1.7.1.min.js"></script>

<script>
$(function() {
    <?
    if ($u) {
        echo "get_bah();";
    }
    ?>
});

function get_bah() {
    var kod_jab = $('#jab').val();
    //alert(kod_jab);
    <?
    $kod_bah = $u ? $person['bah'] : '-';
    //echo "alert('$kod_bah');";
    echo "var kod_bah = '".$kod_bah."';";
    ?>
    $('#bah').load('<?=base_url()?>index.php/staff/cstaff_adm/ajx_bah/'+kod_jab+'/'+kod_bah, {}, function() {
        <?
        if ($u) {
            echo "get_unit();";
        }
        ?>
    });
}

function get_unit() {
    var kod_bah = $('#bahagian').val();
    <?
    $kod_unit = $u ? $person['unit'] : '-';
    //echo "alert('$kod_bah');";
    echo "var kod_unit = '".$kod_unit."';";
    ?>
    //alert(kod_jab);
    $('#unit').load('<?=base_url()?>index.php/staff/cstaff_adm/ajx_unit/'+kod_bah+'/'+kod_unit);
}
</script>
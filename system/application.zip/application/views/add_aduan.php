<h1>Borang Aduan</h1>

<div class="content-box">
				<div class="box-header clear">
										
					<h2>Maklumat Aduan</h2>
				</div>
				
				<div class="box-body clear">
	
					<!-- Custom Forms -->
					<div id="forms" style="display: block;">
						<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/caduan/insert" enctype="multipart/form-data">  
						
							<input type="hidden" name="nama" value="<?php echo $personal['nama']; ?>"  />   
               				<input type="hidden" name="no_kp" value="<?php echo $personal['no_kp']; ?>"  />      
           					<input type="hidden" name="emel" value="<?php echo $personal['emel']; ?>"  />
							<div class="form-field clear">
								<label class="form-label fl-space2" for="textfield">Perkara: <span class="required">*</span></label>
								<input type="text" name="perkara" id="autocomplete" size="40" maxlength="40" value=""  />
       							  <!--<input type="text" id="autocomplete" /> -->
							</div><!-- /.form-field -->
							                             							
							<div class="form-field clear">
								<label class="form-label fl-space2" for="textarea">Keterangan:</label>
								<textarea name="keterangan" class="form-textarea" rows="12" cols="100"  ></textarea>
							</div><!-- /.form-field -->							
														
							<div class="form-field clear">
								<label class="form-label fl-space2">Kategori: </label>
					            <select name="kategori" id="kategori" onchange="get_subkat()">
					                 <option>---Sila Pilih---</option>
					                 <?php foreach($kat as $kategori){ ?>
					                <option value="<?php echo $kategori['id']; ?>"><?php echo $kategori['nama_kategori']; ?></option>
					                 <?php } ?>
					             </select>
							</div><!-- /.form-field -->	
							
						<div class="form-field clear">
						      <span id="subkat"></span>
							</div><!-- /.form-field -->	
							
						<div class="form-field clear">
							<label class="form-label fl-space2">Keutamaan: </label>
				            	<select name="keutamaan">
								<option value="3" >Biasa</option>
								<option value="2" >Sederhana</option>
								<option value="1" >Sangat Penting</option>
								</select>	
			             </div><!-- /.form-field -->
			             	
						<div class="form-field clear">
								<label class="form-label fl-space2" for="file">Lampiran 1:</label>
								<input type="file" name="lampiran1" class="form-file fl" size="40" maxlength="40" value=""  />
								
						</div><!-- /.form-field -->		
						<div class="form-field clear">
								<label class="form-label fl-space2" for="file">Lampiran 2:</label>
								<input type="file" name="lampiran2" class="form-file fl" size="40" maxlength="40" value=""  />
								
						</div><!-- /.form-field -->	
						
						 <div id="fm-submit" class="fm-req">
						      <input name="Submit" value="Hantar" type="submit" />
						       <input name="Reset" value="Reset" type="reset" />
						        <input name="Batal" value="Batal" type="reset" />
						 </div>																							
						</form>
					</div><!-- /#forms -->
					
				</div> <!-- end of box-body -->
			</div>


<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>

<script type="text/javascript">
$(document).ready(function() {
	    $(function() {
	        $( "#autocomplete" ).autocomplete({
	            source: function(request, response,event,ui) {
	                $.ajax({ url: "<?php echo base_url();?>index.php/caduan/json_zip",
	                data: { term: $("#autocomplete").val()},
	                dataType: "json",
	                type: "POST",
	                success: function(data){
	                    //response(data);
	                     response($.map(data.message,function(c){
	                     	
	                     	return {
	                     		value : c.label,
	                     		id:c.value
	                     		}
	                    	 }
	                  ))  //<--- end of response
	                  	
                           }
                      });
                   
	        },
	        minLength: 2,
              select: function(event, ui){
              	
              	location.href = "<?php echo base_url();?>index.php/cfaq/detailfaq/"+ui.item.id;
              }  
                
	        });
	    });
	});

		
		
	</script>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<script src="<?php echo base_url(); ?>js/jquery-1.2.6.js" type="text/javascript" language="javascript"></script> 
<script src="<?php echo base_url(); ?>js/jquery.MultiFile.js" type="text/javascript" language="javascript"></script> 


<?php if (isset($error)) echo $error;?>
<h1>Laman Utama Pentadbir </h1>
<?php if($tahap == "admin"){ ?>
<div id="butang_tambah">
	<a href="<?php base_url();?>add_page">Tambah Artikel</a>
</div>
<?php } ?>
<div class="content-box">
				<div class="box-header clear">
										
					<h2>Muatnaik Gambar untuk artikel Knowledge Base</h2>
				</div>
				
				<div class="box-body clear">
	
					<!-- Custom Forms -->
					<div id="forms" style="display: block;">
						<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/pentadbir/cfaqadmin/image_upload" enctype="multipart/form-data">  
						
							
							<div class="form-field clear">
							     <input type="file" name="userfile[]" size="40" class="multi" />
							</div><!-- /.form-field -->
                             
						 <div id="fm-submit" class="fm-req">
						      <input name="Submit" value="Hantar" type="submit" />
						       <input name="Reset" value="Reset" type="reset" />						       
						 </div>																							
						</form>
					</div><!-- /#forms -->
					
				</div> <!-- end of box-body -->
			</div>



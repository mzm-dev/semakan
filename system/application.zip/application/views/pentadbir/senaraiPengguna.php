<h2>Senarai Aduan</h2>
<table class="jadualh" width="70%" border="1">
<thead>
	<th width="15">ID</th>
	
	<th>Nama</th>

	
	<th width="50">Tindakan</th>
</thead>

<?php foreach($klien as $row){?>
<tr id="tr<?php echo $row['no_kp'] ?>">
	<td><?php echo $row['no_kp'] ?></td>
	
	<td><?php echo $row['nama'] ?></td>
	

	<td align="center">
	<a href="<?php echo base_url();?>index.php/pentadbir/caduanadmin/kemaskini/<?php echo $row['no_kp'];?>"><img src="<?php echo base_url(); ?>images/update.png" border="0"></a> 
	<a href="<?php echo $row['no_kp'] ?>" class="deleteAduan" ><img src="<?php echo base_url(); ?>images/delete.png" border="0"></a>

	</td>
</tr>
<?php } ?>
</table>

<!-- dialog box -->
        <div class="deleteConfirm" title="Pengesahan">
            <p>Anda pasti untuk memadam kes ini?</p>
             
        </div>
 <!-- end dialog box -->
<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">		
	$(document).ready(function(){
    var id;
    $('.deleteAduan').click(function(e){
       id = $(this).attr('href');
       $('.deleteConfirm').dialog('open');
       
       e.preventDefault();
    })
    $('.deleteConfirm').dialog({
        autoOpen : false,
        modal : true,
        buttons : {
              'Yes' : function(){
               $.ajax({
               	   type: "POST",
                   url : 'caduanadmin/padamAduan/' + id,
                   success : function(){
                       // i must remove the div
                       $('.deleteConfirm').dialog('close');
                       $('#tr' + id).slideUp(1000);
                   }
               })
            },
            'No' : function(){
                $(this).dialog('close');
            }
        }
    })
})
</script>
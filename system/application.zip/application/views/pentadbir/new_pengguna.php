<?php
if(isset($msg)){
echo $msg;
} ?>
							
<br><div id="login_form">
	<?php echo validation_errors(); ?>
	<?php
if(isset($telah_wujud)){ ?>
<div class="error">
		<p><?php echo $telah_wujud; ?></p>
</div>	
<?php } ?>
	<h1>Borang Pendaftaran</h1>
<form method="post" action="<?php echo base_url(); ?>index.php/clogin/prosesdaftar">
     <label>Nama:</label>
            <input type="text" name="nama">
     <label>No KP:</label>
            <input type="text" name="no_kp">
     <label>Emel:</label>
            <input type="text" name="emel">
        <label>Kata Laluan:</label>
       <input type="password" name="katalaluan1">
       <label>Sah Kata Laluan:</label>
       <input type="password" name="katalaluan2">

<input type="submit" value="Daftar">
<input type="reset" value="Batal">
</form>
</div>




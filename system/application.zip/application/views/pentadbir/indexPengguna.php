<h1>Pengurusan Pengguna</h1>
<div class="box_c_content">
<ul class="menu_list">
    <li><a href="<?php base_url();?>cPengguna/senaraiPengguna">
    	<span class="ov_nb">Senarai Pengguna</span>
    	</a>
    </li>
    <li><a href="<?php base_url();?>cPengguna/senaraiPetugas">
    	<span class="ov_nb">Senarai Petugas</span>
    	</a>
    </li>
    <li><a href="<?php base_url();?>cPengguna/senaraiPentadbir">
    	<span class="ov_nb">Senarai Pentadbir</span>
    	</a>
    </li>
  
	 
</ul>
</div>




<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">




<script src="<?php echo base_url();?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>



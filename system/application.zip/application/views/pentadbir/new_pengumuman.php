<h1>Tambah Pengumuman</h1>

<div class="content-box">
				<div class="box-header clear">
										
					<h2>Kemasukan maklumat pengumuman</h2>
				</div>
				
				<div class="box-body clear">
	
					<!-- Custom Forms -->
					<div id="forms" style="display: block;">
						<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/pentadbir/cpengumuman/<?php echo ($action == 'add') ? 'insert' : 'update/'.$pengumuman['id'] ?>" enctype="multipart/form-data">  
						                                 							
							<div class="form-field clear">
								<label  class="form-label fl-space2" for="Pengumuman" >Pengumuman</label>
                                                                <textarea name="pengumuman" class="form-textarea" rows="4" cols="70"><?php echo ($action == 'add') ? '' : $pengumuman['teks'] ?></textarea>
							</div><!-- /.form-field -->							
														
							<div class="form-field clear">
								<label class="form-label fl-space2" for="Paparkan">Paparkan?</label>
                                <input type="checkbox" name="papar" value="<?php echo ($action == 'add') ? '' : $pengumuman['papar'] ?>"
                                        <?php if(isset($pengumuman['papar'])&& $pengumuman['papar'] == 1){
                                   		echo "checked=checked";
                                   }?>
                                                                >
							</div><!-- /.form-field -->
						
							
						
						
						 <div id="fm-submit" class="fm-req">
						      <input name="Submit" value="Hantar" type="submit" />
						       <input name="Reset" value="Reset" type="reset" />
						        <input name="Batal" value="Batal" type="reset" />
						 </div>																							
						</form>
					</div><!-- /#forms -->
					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>


<script>

     function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>
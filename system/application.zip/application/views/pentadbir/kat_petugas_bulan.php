<div class="content-box">
				<div class="box-header clear">
						
					<h2>Laporan Statistik Bulanan Mengikut Kategori</h2>
				</div>
				
				<div class="box-body clear">
						<div class="chart"><?php $this->load->view('chart_view', $graph); ?></div>
	<table width="80%" cellpadding="4" cellspacing="1" bgcolor="#666666" align="center" >
		
		<tr bgcolor="#ECF0F4" class="font12" align="center">
		<th>Nama Petugas</td>

		<th>Bilangan Kes</td>
		
			
		</tr>
		
		 <?php
		 $jum = 0;
 	foreach ($laporan->result() as $row)
			{ ?><tr bgcolor="#FFFFFF" class="font12" align="center">
			   <td width="10%"><?php echo $row->nama; ?></td>
			   
			    <td width="10%"><?php echo $row->bil; ?></td></tr>
		<?php } ?>
		
		
		</table>

					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>



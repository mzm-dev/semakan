<h1>Senarai Pengumuman</h1>
<div id="butang_tambah">
	<a href="<?php echo base_url(); ?>index.php/pentadbir/cpengumuman/new_pengumuman">Tambah Pengumuman Baru</a>
</div>
<table class="jadualh" width="70%" border="1">
	<thead>
		<th>Bil</th>
		<th>Tarikh</th>
		<th>Pengumuman</th>
		<th>Papar?</th>
		<th width="80">Tindakan</th>
	</thead>

	<?php
$bil = 1;
foreach($pengumuman as $row){
	?>
	<tr id="tr<?php echo $row['id'] ?>">
		<td><?php echo $bil; ?></td>
		<td><?php echo $row['tarikh']
		?></td>
		<td><?php echo $row['teks']
		?></td>
		<td><?php
			if ($row['papar'] == 1) {echo "Ya";
			}else{echo "Tidak";}
		?></td>
		<td>
			<a href="<?php echo base_url(); ?>index.php/pentadbir/cpengumuman/papar/<?php echo $row['id']; ?>">
				<img src="<?php echo base_url(); ?>images/view.png" border="0"></a> 
			<a href="<?php echo base_url(); ?>index.php/pentadbir/cpengumuman/kemaskini/<?php echo $row['id']; ?>">
				<img src="<?php echo base_url(); ?>images/update.png" border="0"></a>
			 <a href="<?php echo $row['id'] ?>" class="deletePengumuman" ><img src="<?php echo base_url(); ?>images/delete.png" border="0"></a> 
		</td>
	</tr>
	<?php
	$bil++;
	}
	?>
</table>
<!-- dialog box -->
        <div class="deleteConfirm" title="Pengesahan">
            <p>Anda pasti untuk memadam kes ini?</p>
             
        </div>
 <!-- end dialog box -->
 <link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">

<script src="<?php echo base_url();?>js/jqueryui/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">		
	$(document).ready(function(){
    var id;
    $('.deletePengumuman').click(function(e){
       id = $(this).attr('href');
       $('.deleteConfirm').dialog('open');
       
       e.preventDefault();
    })
    $('.deleteConfirm').dialog({
        autoOpen : false,
        modal : true,
        buttons : {
              'Yes' : function(){
               $.ajax({
               	   type: "POST",
                   url : '../../pentadbir/cpengumuman/padamPengumuman/' + id,
                   success : function(){
                       // i must remove the div
                       $('.deleteConfirm').dialog('close');
                       $('#tr' + id).slideUp(1000);
                   }
               })
            },
            'No' : function(){
                $(this).dialog('close');
            }
        }
    })
})
</script>
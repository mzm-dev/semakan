<h1>Laporan Statistik Mengikut Bulan</h1>
<div class="content-box">
				<div class="box-header clear">
										
					<h2>Sila pilih tahun dan bulan</h2>
				</div>
				
				<div class="box-body clear">
	
					<!-- Custom Forms -->
					<div id="forms" style="display: block;">
						<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/pentadbir/claporan/kategori_laporan_bulan" enctype="multipart/form-data">  
						
							
								<div class="form-field clear">
								<label class="form-label fl-space2" for="Tahun">Tahun</label>
                                                                <select name="tahun" id="tahun" >
                                                                    
                                                                     <option value="2012">2012</option>
                                                                      <option value="2011">2011</option>
                                                                     <option value="2010">2010</option>
                                                                </select>
								</div><!-- /.form-field -->
                                 <div class="form-field clear">
								<label class="form-label fl-space2" for="Bulan">Bulan</label>
                                                                <select name="bulan" id="bulan">
                                                                     <option>---Sila Pilih---</option>                                                                     
                                                                    <option value="1">Januari</option>
                                                                    <option value="2">Febuari</option>
                                                                    <option value="3">Mac</option>
                                                                    <option value="4">April</option>
                                                                    <option value="5">Mei</option>
                                                                    <option value="6">Jun</option>
                                                                    <option value="7">Julai</option>
                                                                    <option value="8">Ogos</option>
                                                                    <option value="9">September</option>
                                                                    
                                                                 </select>
							</div><!-- /.form-field -->
                           					
						 <div id="fm-submit" class="fm-req">
						      <input name="Submit" value="Hantar" type="submit" />
						       <input name="Reset" value="Reset" type="reset" />
						        
						 </div>																							
						</form>
					</div><!-- /#forms -->
					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>



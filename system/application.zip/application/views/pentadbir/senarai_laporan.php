<h1>Senarai Laporan</h1>
   <div class="box_c_content">
        <ul class="menu_list">
            <li>
                <a href="<?php base_url();?>claporan/laporan_bulan">
                <span class="ov_nb">Laporan Keseluruhan Mengikut Bulan</span>
                &nbsp;
                </a></li>
            <li><a href="<?php base_url();?>cfaq/senaraikb/3">
                <span class="ov_nb">Laporan Bulanan</span>
                &nbsp;
                </a></li>
           </ul>
                            
</div>
<h1>Senarai Laporan</h1>
Statistik Keseluruhan bagi bulan <?php echo $bulan.' '.$tahun; ?> Mengikut:
   <div class="box_c_content">
        <ul class="senarai_list">
            <li>
                <a href="<?php base_url();?>kat_masalah_bulan/<?php echo $tahun; ?>/<?php echo $bulan; ?>">
                <span class="ov_nb">Kategori Masalah</span>
                </a></li>
            <li><a href="<?php base_url();?>kat_status_bulan/<?php echo $tahun; ?>/<?php echo $bulan; ?>">
                <span class="ov_nb">Status</span>
                          </a></li>
            <li><a href="<?php base_url();?>kat_petugas_bulan/<?php echo $tahun; ?>/<?php echo $bulan; ?>">
                <span class="ov_nb">Petugas</span>
                          </a></li>
            <li><a href="<?php base_url();?>cfaq/senaraikb/3">
                <span class="ov_nb">Kategori dan Status</span>
                          </a></li>
           </ul>
                            
</div>
<h1>Status Aduan</h1>

<div id="color1content">



<div class="field"> 


ID Aduan&nbsp;:&nbsp;<b><?php echo $butiran['id']; ?></b>  &nbsp; &nbsp;
 Dihantar oleh&nbsp;:&nbsp;<b><?php echo $butiran['nama']; ?></b> &nbsp; &nbsp;

 Keutamaan&nbsp;:&nbsp;<b>

<?php echo $butiran['keutamaan']; ?>
</b>
&nbsp; &nbsp;  Status:

<b style="color: #CC3366">
<?php echo $butiran['status']; ?>
</b>
<fieldset>
    <legend>Keterangan Aduan</legend>
<table width="70%">
   
     <tr>
       
        <td><h2><strong><?php echo $butiran['perkara']; ?></strong></h2></td>
    </tr>
     <tr>
        
        <td><?php echo $butiran['keterangan']; ?></td>
    </tr>

</table> 

</fieldset>

</div>


</div> <!-- end color Div -->

<?php if($tahap == 'admin'){ ?>
<form id="fm-form"  method="post" 
action="<?php echo base_url(); ?>index.php/pentadbir/caduanadmin/kemaskiniAgihan/<?php echo $butiran['id']; ?>">
	 <fieldset>
    <legend>Agihan Kes</legend>
                
  <div class="fm-req">
      <label for="Kategori">Diagihkan kepada</label>
            <select name="pegawai_kes" id="pegawai_kes">
                 <option>---Sila Pilih---</option>                                  
                <?php foreach($petugas as $row){           	?>
                	<?php 
                 if(($butiran['pegawai_kes']!='') && ($butiran['pegawai_kes'] == $row['no_kp'])){ 
                 	$selected="selected='selected'";					
                   }else{
					 $selected="";	  
				   }?>
                <option <?php echo $selected; ?> value="<?php echo $row['no_kp']; ?>"><?php echo $row['nama']; ?></option>
                 <?php $selected="";		
				}?>
             </select>
             </div>
  
</fieldset>
   <div id="fm-submit" class="fm-req">
      <input name="Submit" value="Hantar" type="submit" />
       <input name="Reset" value="Reset" type="reset" />
        <input name="Batal" value="Batal" type="reset" />
	<input type="hidden" name="id_pengagih" value="<?php echo $id; ?>"/>
    </div>
</form>
<?php } ?>

<table border="0" cellpadding="6" cellspacing="1" width="100%"  style="border: 1px solid rgb(225,225,225)">
	<tr>
		<td background="http://www.webhelpdesk-software.com/demo/bar6.gif">
			From: Malou Ocampo | Email: 123@yahoo.com
		</td>
	</tr>
	<tr>
		<td>
			Dihantar pada:
		</td>
	</tr>
	<tr>
		<td>
			Isi kandungan
		</td>
	</tr>
</table>
<br>

<form id="fm-form"  method="post" 
action="<?php echo base_url(); ?>index.php/pentadbir/caduanadmin/kemaskiniAgihan/<?php echo $butiran['id']; ?>">

<table border="0" cellpadding="6" cellspacing="1" width="100%"  style="border: 1px solid rgb(225,225,225)">
  <tr>
    <td background="http://www.webhelpdesk-software.com/demo/bar6.gif"><span class="normaltext"><strong> Tulis Maklumbalas </strong></span></td>
  </tr>
  <tr>
    <td><span class="normaltext">

      <textarea rows="19" name="msg_reply" cols="84" style="width:100%"></textarea>
    </span></td>
  </tr>
  <tr>
    <td><span class="normaltext"><img src="http://www.webhelpdesk-software.com/demo/first.gif"> <strong> Lampiran: </strong>
      <input type="file" name="attatch1" size="50"      >
      </span>

      <p>
        <span class="normaltext">
        <input type="submit"      value="Post Reply" name="B1" >
         </tr>
</table>
</form>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/smoothness/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>
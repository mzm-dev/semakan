<?php echo ($action == 'add') ? 'Write a blog' : 'Edit blog' ?>
<script type="text/javascript" src="<?php echo base_url(); ?>js/tinymce/jscripts/tiny_mce/tiny_mce.js" >
            </script>
<script type="text/javascript">
tinyMCE.init({
        // General options
        mode : "textareas",
        theme : "advanced",
        plugins : "autolink,lists,spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",
        relative_urls : false,
        remove_script_host : false,
        document_base_url : "http://localhost/help_desk/",

        // Theme options
        theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
        theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
        theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
        theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,spellchecker,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,blockquote,pagebreak,|,insertfile,insertimage",
        theme_advanced_toolbar_location : "top",
        theme_advanced_toolbar_align : "left",
        theme_advanced_statusbar_location : "bottom",
        theme_advanced_resizing : true,

        // Skin options
        skin : "o2k7",
        skin_variant : "silver",

        // Example content CSS (should be your site CSS)
        content_css : "css/example.css",

        // Drop lists for link/image/media/template dialogs
        template_external_list_url : "js/template_list.js",
        external_link_list_url : "js/link_list.js",
        external_image_list_url : "http://localhost/help_desk/js/image_list.php",
        media_external_list_url : "http://localhost/help_desk/js/media_list.js",

        // Replace values for the template plugin
        template_replace_values : {
                username : "Some User",
                staffid : "991234"
        }
});
</script>

<h1>Laman Utama Pentadbir : Tambah FAQ</h1>
<?php if($tahap == "admin"){ ?>
<div id="butang_tambah">
	<a href="<?php base_url();?>add_image">Muatnaik Gambar Artikel</a>
</div>
<?php } ?>
<div class="content-box">
				<div class="box-header clear">
										
					<h2>Kemasukan maklumat Knowledge Base</h2>
				</div>
				
				<div class="box-body clear">
	
					<!-- Custom Forms -->
					<div id="forms" style="display: block;">
					
						<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/pentadbir/cfaqadmin/<?php echo ($action == 'add') ? 'insert' : 'update/'.$faq['id'] ?>" enctype="multipart/form-data">  
						<input type="hidden" name="id_faq" value="<?php echo ($action == 'add') ? '' : $faq['id'] ?>">
							
							<div class="form-field clear">
								<label class="form-label fl-space2" for="Tajuk">Tajuk</label>
								
                                  <input type="text" name="soalan" size="60" id="soalan" value="<?php echo ($action == 'add') ? '' : $faq['soalan'] ?>">
							</div><!-- /.form-field -->
                                                        <div class="form-field clear">
								<label class="form-label fl-space2" for="Kategori">Kategori</label>
                                                                <select name="kategori" id="kategori" onchange="get_subkat()">
                                                                     <option>---Sila Pilih---</option>
                                                                     <?php foreach($kat as $kategori){ ?>
                                                                     	<?php 
												                        if(($faq['id']!='') && ($faq['kategori'] == $kategori['id'])){ 
												                 	$selected="selected='selected'";					
												                            }else{
												                                 $selected="";	  
												                           }?>
                                                                    <option <?php echo $selected; ?> value="<?php echo $kategori['id']; ?>"><?php echo $kategori['nama_kategori']; ?></option>
                                                                     <?php 
																	 $selected="";
																	 } ?>
                                                                 </select>
							</div><!-- /.form-field -->
                                                        
                                                        <div class="form-field clear">
                                                        <input type="hidden" name="kod_sub" id="kod_sub" value="<?php echo ($action == 'add') ? '' : $faq['sub_kategori'] ?>">
												      <span id="subkat"></span>
													</div><!-- /.form-field -->	
							                             							
							<div class="form-field clear">
								<label  class="form-label fl-space2" for="Kandungan" >Kandungan</label>
                                                                <textarea name="jawapan" class="form-textarea" rows="12" cols="80">
                                                                	<?php echo ($action == 'add') ? '' : $faq['jawapan'] ?>
                                                                </textarea>
							</div><!-- /.form-field -->							
														
							<div class="form-field clear">
								<label class="form-label fl-space2" for="Paparkan">Paparkan?</label>
                                   <input type="checkbox" name="papar" value="<?php echo ($action == 'add') ? '' : $faq['papar'] ?>"
                                    <?php if(isset($faq['papar'])&& $faq['papar'] == 1){
                                   		echo "checked=checked";
                                   }?>
                                   >
							</div><!-- /.form-field -->
						
							
						
						
						 <div id="fm-submit" class="fm-req">
						        <input name="submit" value="Hantar" type="submit" />						     
						        <input name="batal" value="Batal" type="reset" />
						 </div>																							
						</form>
					</div><!-- /#forms -->
					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>
<script type="text/javascript">  
$(document).ready(function() {
  // Handler for .ready() called.
  get_subkat();
});
     function get_subkat(){
        var kod_kat = $('#kategori').val();
         var kod_sub = $('#kod_sub').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat+'/'+kod_sub);
    }

</script>


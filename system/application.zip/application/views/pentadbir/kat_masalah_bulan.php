<div class="content-box">
				<div class="box-header clear">
						
					<h2>Laporan Statistik Bulanan Mengikut Kategori</h2>
				</div>
				
				<div class="box-body clear">
						<div class="chart"><?php $this->load->view('chart_view', $graph); ?></div>
					<table width="80%" cellpadding="4" cellspacing="1" bgcolor="#666666" align="center" >
		
				<tr align="center" bgcolor="#ECF0F4" class="font12">

		
		<th colspan="4">Kategori Masalah</th>
		<td>&nbsp;</td>
		
		</tr>
		
		<tr bgcolor="#ECF0F4" class="font12" align="center">
		<th>Sistem Aplikasi</td>

		<th>Teknikal</td>
		<th>Rangkaian</td>
			<th>Password/Email</td>
			<th>Jumlah</td>
		</tr>
		
				<tr bgcolor="#FFFFFF" class="font12" align="center">
		
		 <?php
		 $jum = 0;
 	foreach ($laporan->result() as $row)
			{
			   echo '<td width="10%">'.$row->bil.'</td>';
			   
			   $jum += $row->bil;
			}
			echo '<td width="10%">'.$jum.'</td>';
 ?>
		
		
		</tr>
				
				
		<tr align="center" bgcolor="#ECF0F4" class="font12">
		<td colspan="10">&nbsp;</td>
		</tr>
		</table>

					
				</div> <!-- end of box-body -->
			</div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>



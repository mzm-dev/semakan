 <div id="page-subheader">
               
            <nav id="sub-nav">
                        <ul>
                        	<?php
                        	 if($tahap == 'admin'){ ?>
                        <li class="active"> <a href="<?php echo base_url(); ?>index.php/pentadbir/cadmin">Laman Utama</a></li>
                         <?php }elseif($tahap == 'petugas'){ ?>
                         <li class="active"><a href="<?php echo base_url(); ?>index.php/petugas/cpetugas">Laman Utama</a></li>
                         <?php }else{ ?>
                        <li class="active"><a href="<?php echo base_url(); ?>index.php/clogin">Laman Utama</a></li>
                        <?php } ?>                                                
                            <li><a href="<?php echo base_url();?>index.php/cfaq">Knowledge Base</a></li>
                            <li><a href="<?php echo base_url();?>index.php/cinteract">Interaksi</a></li>
                            <li><a href="<?php echo base_url();?>index.php/pentadbir/cpengumuman">Pengumuman</a></li>
                            <li><a href="<?php echo base_url();?>index.php/pentadbir/cpengguna">Pengguna</a></li>
                             <li><a href="<?php echo base_url();?>index.php/pentadbir/claporan">Laporan</a></li>
                            
                        </ul>
                    </nav>
                  <span ><a class="logout" href="<?php echo base_url(); ?>index.php/clogin/logout">Log Keluar</a></span>
                    </div>
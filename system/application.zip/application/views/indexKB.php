<h1>Knowledge Base</h1>
<?php if($tahap == "admin"){ ?>
<div id="butang_tambah">
	<a href="<?php base_url();?>pentadbir/cfaqadmin/add_page">Tambah Artikel</a>
	<a href="<?php base_url();?>pentadbir/cfaqadmin/add_image">Muatnaik Gambar Artikel</a>
</div>
<?php } ?>
<div class="content-box">
				<div class="box-header clear">
										
					<h2>Carian Knowledge Base</h2>
				</div>
				
				<div class="box-body clear">
	
			<!-- Custom Forms -->
			<div id="forms" style="display: block;">
				<form class="borang"  method="post" action="<?php echo base_url(); ?>index.php/cfaq/carianFaqMain" enctype="multipart/form-data">  
				<div class="form-field clear">
					<input type="text" name="perkara" id="autocomplete" size="40" maxlength="40" value=""  /> <input name="Cari" value="Cari" type="submit" />
       				</div><!-- /.form-field -->
				</form>
        <?php if (isset($_POST['Cari'])){ ?>
<h1>Hasil Carian untuk frasa '<?php echo $match; ?>'</h1>
	<table class="jadualh" width="80%" border="1">
            <thead>
                    <th>Kategori</th>
                    <th>Sub-Kategori</th>
                    <th width="250">Soalan</th>
                    <th width="100">Tindakan</th>
            </thead>
        <?php 
        if(isset($query)){
        foreach($query as $item){?>
        <tr id="tr<?php echo $item['id'] ?>">
        <td><?php echo $this->MKategori->getNamaKategori($item['kategori']); ?></td>
        <td><?php if($item['sub_kategori'] != 0){
				echo $this->MKategori->getNamaSubKategori($item['sub_kategori']);
				}else{
				echo '-';	
				}
				?>
                </td>
        <td><?php echo $item['soalan'] ?></td>
        <td>        	
        	<a href="<?php echo base_url(); ?>index.php/cfaq/detailfaq/<?php echo $item['id']; ?>">
        		<img src="<?php echo base_url(); ?>images/view.png" border="0"></a>
        	   <a href="<?php echo base_url(); ?>index.php/pentadbir/cfaqadmin/updateFaq/<?php echo $item['id']; ?>">
                  <img src="<?php echo base_url(); ?>images/update.png" border="0"></a>
                  <a href="<?php echo $item['id'] ?>" class="deleteFaq" ><img src="<?php echo base_url(); ?>images/delete.png" border="0"></a>

        </td>
        </tr>
        <?php 
			}
			}else{
			  echo '<tr>
                <td colspan=4 align=center>-Maklumat Yang Dicari Tidak Wujud Dalam Rekod-</td></tr>'; 
			} ?>
            </table>	
<?php } ?>
				</div> <!-- end of box-body -->
</div>
    <br>

				<div class="box-header clear">
										
					<h2>Kategori Knowledge Base</h2>
				</div>
				
				<div class="box-body clear">
	
					<div class="box_c_content">
<ul class="menu_list">
    <li>
        <a href="<?php echo base_url();?>cfaq/senaraikb/1">
    	<span class="ov_nb">Perkakasan</span>
        Desktop, Komputer Riba, Pencetak
    	</a></li>
    <li><a href="<?php echo base_url();?>cfaq/senaraikb/4">
        <span class="ov_nb">Perisian</span>
        MS Office, Adobe, Dewan Eja
    	</a></li>
   </ul>
                            
</div>
   <div class="box_c_content">
        <ul class="menu_list">
            <li>
                <a href="<?php echo base_url();?>cfaq/senaraikb/2">
                <span class="ov_nb">Rangkaian</span>
                &nbsp;
                </a></li>
            <li><a href="<?php echo base_url();?>cfaq/senaraikb/3">
                <span class="ov_nb">Emel/Password</span>
                &nbsp;
                </a></li>
           </ul>
                            
</div>
					
				</div> <!-- end of box-body -->
</div>

<!-- dialog box -->
        <div class="deleteConfirm" title="Pengesahan">
            <p>Anda pasti untuk memadam kes ini?</p>
             
        </div>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">



<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>

<script type="text/javascript">
$(document).ready(function() {
	    $(function() {
	        $( "#autocomplete" ).autocomplete({
	            source: function(request, response,event,ui) {
	                $.ajax({ url: "<?php echo base_url();?>index.php/caduan/json_zip",
	                data: { term: $("#autocomplete").val()},
	                dataType: "json",
	                type: "POST",
	                success: function(data){
	                    //response(data);
	                     response($.map(data.message,function(c){
	                     	
	                     	return {
	                     		value : c.label,
	                     		id:c.value
	                     		}
	                    	 }
	                  ))  //<--- end of response
	                  	
                           }
                      });
                   
	        },
	        minLength: 5,
              select: function(event, ui){
              	
              	location.href = "<?php echo base_url();?>index.php/cfaq/detailfaq/"+ui.item.id;
              }  
                
	        });
	    });
	});

	</script>
	<script type="text/javascript">        
    $(document).ready(function(){
    var id;
    $('.deleteFaq').click(function(e){
       id = $(this).attr('href');
       $('.deleteConfirm').dialog('open');
       
       e.preventDefault();
    })
    $('.deleteConfirm').dialog({
        autoOpen : false,
        modal : true,
        buttons : {
              'Yes' : function(){
               $.ajax({
                   type: "POST",
                   url : '../../pentadbir/cfaqadmin/padamFaq/' + id,
                   success : function(){
                       // i must remove the div
                       $('.deleteConfirm').dialog('close');
                       $('#tr' + id).slideUp(1000);
                   }
               })
            },
            'No' : function(){
                $(this).dialog('close');
            }
        }
    })
})
</script>
<h1>Status Aduan</h1>
<form id="fm-form"  method="post" action="<?php echo base_url(); ?>index.php/caduan/butiranaduan">
 
    <fieldset>
    
Sila masukkan emel dan no rujukan aduan.
                 <div class="fm-req">
        <label>Emel: </label>
	<input type="text" name="emel" size="40" maxlength="40" value=""  />
         </div>
           <div class="fm-req">   <div class="fm-req">
        <label>Kod Rujukan:</label>
	<input type="text" name="rujukan" size="40" maxlength="40" value=""  />
               </div>
    </fieldset>
    

   
    <div id="fm-submit" class="fm-req">
      <input name="Submit" value="Semak" type="submit" />
       <input name="Reset" value="Reset" type="reset" />
        <input name="Submit" value="Submit" type="submit" />

    </div>
 

   
</form>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/caduan/ajx_subkat/'+kod_kat);
    }

</script>
<?php
//session_start();
$me = $id;
$_SESSION['username'] = $me; // Must be already set
?>

<link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url(); ?>chat/css/chat.css" />
<!--<link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url(); ?>chat/css/screen.css" /> -->

<!--[if lte IE 7]>
<link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url(); ?>chat/css/screen_ie.css" />
<![endif]-->

</head>
<body>
<div id="main_container">
    <p>Klik pada link dibawah untuk memulakan sesi chat. </p>
<a href="javascript:void(0)" onclick="javascript:chatWith('<?php echo $you; ?>')">Chat With <?php echo $you; ?></a>
<!-- YOUR BODY HERE -->

</div>

<script type="text/javascript" src="<?php echo base_url();?>chat/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>chat/js/chat.js"></script>


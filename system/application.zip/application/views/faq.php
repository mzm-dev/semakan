<h1>FAQ</h1>
<form method="post" action="<?php echo base_url(); ?>index.php/cfaq/carianfaq">
<input type="text" name="carian_faq" id="carian_faq">
            <select name="kategori" id="kategori" onchange="get_subkat()">
                 <option>---Sila Pilih---</option>
                 <?php foreach($kat as $kategori){ ?>
                <option value="<?php echo $kategori['id']; ?>"><?php echo $kategori['nama_kategori']; ?></option>
                 <?php } ?>
             </select>
<span id="subkat"></span>
<br>
<input type="submit" name="cari" value="Cari">
</form>

<?php if (isset($_POST['cari'])){ ?>
<h2>Hasil Carian</h2>
<table border="1" width="60%">
<tr><th>Soalan</th>
<th>Jawapan</th>
</tr>
<?php foreach($query as $item){?>
<tr>
<td><?php echo $item['soalan'] ?></td>
<td><?php echo $item['jawapan'] ?></td>
</tr>
<?php } ?>
</table>
<?php } ?>

<link rel="stylesheet" href="<?php echo base_url();?>js/jqueryui/css/humanity/jquery-ui-1.8.18.custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>js/treeview/jquery.treeview.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/mytree.css">


<script src="<?php echo base_url();?>js/treeview/lib/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/lib/jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/treeview/jquery.treeview.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jqueryui/js/jquery-ui-1.8.18.custom.min.js" type="text/javascript"></script>

<script>

    function get_subkat(){
        var kod_kat = $('#kategori').val();
        $('#subkat').load('<?php echo base_url();?>index.php/cfaq/ajx_subkat/'+kod_kat);
    }

</script>
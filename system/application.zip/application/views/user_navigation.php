 <div id="page-subheader">
               
            <nav id="sub-nav">
                        <ul>
                        	<?php
                        	 if($tahap == 'admin'){ ?>
                          <li <?php if($page=="home_admin"){ echo "class=active";} ?>> <a href="<?php echo base_url(); ?>index.php/pentadbir/cadmin">Laman Utama</a></li>
                         <?php }elseif($tahap == 'petugas'){ ?>
                          <li <?php if($page=="home_petugas"){ echo "class=active";} ?>><a href="<?php echo base_url(); ?>index.php/petugas/cpetugas">Laman Utama</a></li>
                         <?php }else{ ?>
                          <li <?php if($page=="home_user"){ echo "class=active";} ?>><a href="<?php echo base_url(); ?>index.php/clogin">Laman Utama</a></li>
                        <?php } ?>
                        	
                           
                   <li <?php if($page=="aduan"){ echo "class=active";} ?>>
                   	<a href="<?php echo base_url();?>index.php/caduan">Aduan Baru</a>
                   	</li>
                   <li <?php if($page=="status_aduan"){ echo "class=active";} ?>>
                   	<a href="<?php echo base_url();?>index.php/caduan/statusaduan">Status Aduan</a>
                   </li>
                   <li <?php if($page=="kb"){ echo "class=active";} ?>>
                   	<a href="<?php echo base_url();?>index.php/cfaq">Knowledge Base</a></li>
                    <li <?php if($page=="interact"){ echo "class=active";} ?>>
                    <a href="<?php echo base_url();?>index.php/cinteract">Interaksi</a></li>
                            
                        </ul>
                    </nav>
                  <span ><a class="logout" href="<?php echo base_url(); ?>index.php/clogin/logout">Log Keluar</a></span>
                    </div>
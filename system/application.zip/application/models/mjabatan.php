<?php
class MJabatan extends Model{
    function MJabatan(){
        parent::Model();
    }

    function getJabatan(){
        $data = array();
        $this->db->where('kat','jab');
        $Q = $this->db->get('kod_rujukan');

        if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

     function getBahagian($kod_jab){
        $data = array();
        $this->db->where('kod_jab',$kod_jab);
        $Q = $this->db->get('bahagian');

        if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

    function getUnit($kod_bah){
        $data = array();
        $this->db->where('kod_jabatan',$kod_bah);
        $Q = $this->db->get('unit');

        if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }
     

}

?>

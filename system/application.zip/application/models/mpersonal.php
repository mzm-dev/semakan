<?php
class MPersonal extends Model{
    function MPersonal(){
        parent::Model();
    }

    function insertPerson($data){
       $this->db->insert('personal',$data);
    }

    function login($user_id,$pwd){
        $this->db->where('no_kp',$user_id);
        $this->db->where('katalaluan',$pwd);
       $Q = $this->db->get('personal');
   
        if($Q->num_rows() > 0){
            return true;
        }else{
            false;
            }
    }

    function getPersonal($user_id){
        $data = array();
        $this->db->where('no_kp',$user_id);
        $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;

    }
	
	    
    function getNama($user_id){
        $data = array();
        $this->db->where('no_kp',$user_id);
        $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
			 return $data['nama'];
        }else{
        	return '-';
        }
       
        
    }

    function getPersonalByUnit($kod_unit){
        $data = array();
        $this->db->where('unit',$kod_unit);
        $Q = $this->db->get('personal');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }
	
	function getPersonalByTahap($tahap){
        $data = array();
        $this->db->where('tahap',$tahap);
        $Q = $this->db->get('personal');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

    function is_reset($user_id) {

            $arr_person = $this->getPersonal($user_id);
          $reset_dt = strtotime($arr_person['tkh_katalaluan']);
          //echo $arr_person['tkh_katalaluan'];
          $dt = getdate($reset_dt);

          $month = $dt['mon'];
          $day = $dt['mday'];
          $year = $dt['year'];

          $next_dt = mktime(0,0, 0, $month, $day + 90, $year);

          //echo date('d/m/y',$next_dt);
          $today = mktime();

           if($next_dt < $today){
                return true;
           }else{
                return false;
           }

        }
	
	function getOnlineUser(){
		$data = array();
		$query = $this->db->query("SELECT b.no_kp, b.nama, (a.timestamp) AS masa, unix_timestamp( ) AS skrg, (
								unix_timestamp( ) -1440) AS lepas
								FROM usertracking a, personal b
								WHERE b.tahap = 'petugas'
								AND (a.timestamp +1440) >= unix_timestamp( ) 
								AND a.user_identifier = b.no_kp
								GROUP BY b.no_kp
								 ");
		
		return $query;
		
	}
        
    }

?>

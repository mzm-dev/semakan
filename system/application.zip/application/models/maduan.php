<?php
class MAduan extends Model{
    function MAduan(){
        parent::Model();
    }

    function insert($data){
       $this->db->insert('aduan',$data);
    }

    function aduanTerakhir()
    {
        $this->db->select_max('id');
	$Q = $this->db->get('aduan');
	$row = $Q->row_array();
	return $row['id'];
    }
	
	function padamAduan($id_aduan)
    {
        $this->db->delete('aduan', array('id' => $id_aduan)); 
    }
	
	function terimaAduan($id_aduan)
    {
        $data = array(
				'status' => 'Dalam Tindakan'               
         );

			$this->db->where('id', $id_aduan);
			$this->db->update('aduan', $data); 
    }

    function semakAduan($emel,$id_aduan)
    {
        $data = array();
        $this->db->where('emel',$emel);
       $this->db->where('id',$id_aduan);
       $Q = $this->db->get('aduan');
         if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;
    }
    
    function senaraiAduanPengadu($no_kp)
    {
        $data = array();        
       $this->db->where('no_kp',$no_kp);
       $Q = $this->db->get('aduan');
         if($Q->num_rows() > 0){
           foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function butiranAduan($id_aduan)
    {
        $data = array();
         $this->db->where('id',$id_aduan);
       $Q = $this->db->get('aduan');
         if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;
    }
	
	function updateAgihan($id_aduan){
		$data = array(
				'status' => 'Diagih',
               'pegawai_kes' => $this->input->post('pegawai_kes'),
               'diagih_oleh' => $this->input->post('id_pengagih'),
               'tarikh_agih' => date( 'Y-m-d H:i:s')
         );

			$this->db->where('id', $id_aduan);
			$this->db->update('aduan', $data); 
	}

    function cariFaq()
     {
        $match = $this->input->post('carian_faq');
         $match2 = $this->input->post('kategori');
         $match3 = $this->input->post('sub_kategori');
        $this->db->like('soalan',$match);
        $this->db->or_like('jawapan',$match);
       // $this->db->or_like('kategori',$match2);
       // $this->db->or_like('sub_kategori',$match3);
        $Q = $this->db->get('faq');
         if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
        }

    function login($user_id,$pwd){
        $this->db->where('no_kp',$user_id);
        $this->db->where('katalaluan',$pwd);
       $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            return true;
        }else{
            false;
            }
    }

    function getPersonal($user_id){
        $data = array();
        $this->db->where('no_kp',$user_id);
        $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;

    }

    function getAduanBaru(){
        $data = array();
        $this->db->where('status','Baru');
        $Q = $this->db->get('aduan');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

    function getAduanDiagih(){
        $data = array();
        $this->db->where('status','Diagih');
        $Q = $this->db->get('aduan');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function insertMklmBlsAduan($data){       
		$this->db->insert('mklm_bls_aduan',$data);
    }
	
	function getMklmBlsAduan($id){       
		$data = array();
		 $this->db->where('id_aduan',$id);
		 $this->db->order_by("tarikh_mklm_bls", "desc");
        $Q = $this->db->get('mklm_bls_aduan');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function getAduanDiagihByPegawaiKes($pegawai_kes){
        $data = array();
		 $this->db->where('pegawai_kes',$pegawai_kes);
        $this->db->where('status','Diagih');
        $Q = $this->db->get('aduan');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function getAduanDlmTindakanByPegawaiKes($pegawai_kes){
        $data = array();
		 $this->db->where('pegawai_kes',$pegawai_kes);
        $this->db->where('status','Dalam Tindakan');
        $Q = $this->db->get('aduan');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function updateStatusAduan($id_aduan){
		$data = array(
				'status' => 'Selesai'
         );

			$this->db->where('id', $id_aduan);
			$this->db->update('aduan', $data); 
	}

    function getKeutamaan($kod_keutamaan){
        $data = array();
        $this->db->where('kod',$kod_keutamaan);
        $Q = $this->db->get('keutamaan');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data['keterangan'];
    }

    function stat_kat_bulan($tahun,$bulan){
    	$data = array();
		$query = $this->db->query("SELECT COUNT( a.ID ) AS bil, kategori
								 FROM aduan a ,kategori b WHERE YEAR( tarikh_aduan ) ='$tahun'
								 AND MONTH( tarikh_aduan ) ='$bulan'
								 AND a.kategori = b.id
								 GROUP BY kategori
								 ");
		
		return $query;
    }
	
	function stat_status_bulan($tahun,$bulan){
    	$data = array();
		$query = $this->db->query("SELECT COUNT( ID ) AS bil, status
								 FROM aduan  WHERE YEAR( tarikh_aduan ) ='$tahun'
								 AND MONTH( tarikh_aduan ) ='$bulan'
								 GROUP BY status
								 ");
		
		return $query;
    }
	
	function stat_petugas_bulan($tahun,$bulan){
    	$data = array();
		$query = $this->db->query("SELECT COUNT( ID ) AS bil, a.pegawai_kes, b.nama
								 FROM aduan a, personal b  WHERE YEAR( tarikh_aduan ) ='$tahun'
								 AND MONTH( tarikh_aduan ) ='$bulan'
								 AND a.pegawai_kes = b.no_kp
								 GROUP BY pegawai_kes
								 ");
		
		return $query;
    }
    
   
 }

?>

<?php
class MFaq extends Model{
    function MFaq(){
        parent::Model();
    }

    function insertFaq($data){
       $this->db->insert('faq',$data);
    }
	
	 function updateFaq($id_faq,$data){
       $this->db->where('id', $id_faq);
	   $this->db->update('faq', $data); 
    }
	 
	function padamFaq($id_faq)
    {
        $this->db->delete('faq', array('id' => $id_faq)); 
    }

    function cariFaq()
     {
        $match = $this->input->post('perkara');
		
		$matchs = explode(' ',$match);
       foreach($matchs as $keyword){
       	 $this->db->or_like('soalan',$keyword);
	   }
        $Q = $this->db->get('faq');
         if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
				
            }
        
        return $data;}
        }
	 
	 function cariRelatedFaq($match)
     {
       		
		$matchs = explode(' ',$match);
       foreach($matchs as $keyword){
       	 $this->db->or_like('soalan',$keyword);
	   }
        $Q = $this->db->get('faq');
         if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
				
            }
        
        return $data;}
        }
	 
    function detailFaq($id_faq){
	 	$data = array();
	 	$this->db->where('id',$id_faq);
		$Q = $this->db->get('faq');
		if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;
	 	
	 }

    function autoCompleteFaq(){
                $match = $this->input->post('term');
				//$match = 'so';
                 $this->db->like('soalan',$match);
	        $query = $this->db->get('faq');
	        return $query->result();
    }
	
	function autoJson(){
                $match = $this->input->post('term');
						
		$terms = explode(' ',$match);
       foreach($terms as $keyword){
       	 $this->db->or_like('soalan',$keyword);
	   }
                
	        $query = $this->db->get('faq');
	        return $query->result();
    }

    function login($user_id,$pwd){
        $this->db->where('no_kp',$user_id);
        $this->db->where('katalaluan',$pwd);
       $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            return true;
        }else{
            false;
            }
    }

    function getPersonal($user_id){
        $data = array();
        $this->db->where('no_kp',$user_id);
        $Q = $this->db->get('personal');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;

    }

    function getPersonalByUnit($kod_unit){
        $data = array();
        $this->db->where('unit',$kod_unit);
        $Q = $this->db->get('personal');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
    
    function getSenaraiKB($kod_kategori){
        $data = array();
        $this->db->where('kategori',$kod_kategori);
        $Q = $this->db->get('faq');

       if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }

    function is_reset($user_id) {

            $arr_person = $this->getPersonal($user_id);
          $reset_dt = strtotime($arr_person['tkh_katalaluan']);
          //echo $arr_person['tkh_katalaluan'];
          $dt = getdate($reset_dt);

          $month = $dt['mon'];
          $day = $dt['mday'];
          $year = $dt['year'];

          $next_dt = mktime(0,0, 0, $month, $day + 90, $year);

          //echo date('d/m/y',$next_dt);
          $today = mktime();

           if($next_dt < $today){
                return true;
           }else{
                return false;
           }

        }

    }

?>

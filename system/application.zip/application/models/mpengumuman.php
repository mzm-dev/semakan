<?php
class MPengumuman extends Model{
    function MPengumuman(){
        parent::Model();
    }

    function insertPengumuman($data){
       $this->db->insert('pengumuman',$data);
    }
	
	 function updatePengumuman($id_pengumuman,$data){
       $this->db->where('id', $id_pengumuman);
	   $this->db->update('pengumuman', $data); 
    }
	 
	function padamPengumuman($id_pengumuman)
    {
        $this->db->delete('pengumuman', array('id' => $id_pengumuman)); 
    }
    
    function senaraiPengumuman($papar)
    {
        $data = array(); 
		
		if($papar == 1)  {  
       $this->db->where('papar','1');
		}
       $Q = $this->db->get('pengumuman');
         if($Q->num_rows() > 0){
           foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;
    }
	
	function detailPengumuman($id_pengumuman){
		$data = array();
	 	$this->db->where('id',$id_pengumuman);
		$Q = $this->db->get('pengumuman');
		if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;
	}
		

    
    
   
 }

?>

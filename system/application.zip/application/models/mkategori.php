<?php
class MKategori extends Model{
    function MKategori(){
        parent::Model();
    }

    function getKategori(){
        $data = array();
       // $this->db->where('kat','jab');
        $Q = $this->db->get('kategori');

        if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

    function getKategoriID($kategori){
        $data = array();
        $this->db->where('id',$kategori);
        $Q = $this->db->get('kategori');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data;

    }
    
    function getNamaKategori($kategori){
        $data = array();
        $this->db->where('id',$kategori);
        $Q = $this->db->get('kategori');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data['nama_kategori'];

    }
    function getNamaSubKategori($sub_kategori){
        $data = array();
        $this->db->where('id',$sub_kategori);
        $Q = $this->db->get('sub_kategori');

        if($Q->num_rows() > 0){
            $data = $Q->row_array();
        }
        return $data['nama_subkategori'];

    }

     function getSubKategori($kod_kat){
         $data = array();
        $this->db->where('kod_kategori',$kod_kat);
        $Q = $this->db->get('sub_kategori');

        if($Q->num_rows() > 0){
            foreach($Q->result_array() as $row){
            $data[] = $row;
            }
        }
        return $data;

    }

    


}

?>
